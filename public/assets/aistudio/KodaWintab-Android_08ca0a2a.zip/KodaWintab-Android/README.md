# Koda Wintab — Android nativo (alpha)

Projeto Android Studio em Kotlin + Jetpack Compose, convertido a partir do protótipo React/TypeScript enviado.

## Plataforma

- `minSdk = 29` (Android 10)
- `targetSdk = 34` (Android 14)
- `compileSdk = 35`
- Kotlin `2.0.21`
- Android Gradle Plugin `8.7.3`
- JDK `17`

## Abrir e compilar

1. Instale Android Studio atualizado e o Android SDK Platform 35 (e Build Tools correspondentes).
2. Abra a pasta `KodaWintab-Android` no Android Studio.
3. Aguarde a sincronização Gradle e aceite a instalação das dependências.
4. Para gerar APK debug: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Também é possível compilar em terminal, com Gradle 8.9 instalado e JDK 17:

```bash
gradle assembleDebug
```

## O que esta versão já contém

- Projeto Android Gradle padrão, Manifest e Activity nativa.
- Interface Kotlin/Compose: Ativação, Home, Mesa (abas Tablet/Pen/Bindings/Filters/Output), Hub, Coop e Arquitetura.
- Enumeração real dos dispositivos USB conectados usando `UsbManager`.
- Identificação VID/PID, interfaces, indicação de provável dispositivo HID e solicitação de permissão USB do Android.
- Inspeção básica do tamanho de `rawDescriptors` quando a permissão USB foi concedida.
- Serviço foreground declarado para o ciclo de vida futuro do driver USB.
- Funções puras iniciais de transformação de coordenadas e curva de pressão em `TabletMath.kt`.
- Catálogo inicial de perfis VID/PID em `app/src/main/assets/tablet_profiles.json`.
- Protótipo React/TypeScript original preservado em `reference-web-prototype/` para consulta.

## Limitações explícitas desta alpha

Esta entrega é uma base Android compilável e uma conversão da interface, não um driver de mesa completo. Não afirma recursos que ainda não existem:

- O parser HID real de Ugee S640, Wacom, Huion e XP-Pen ainda precisa ser implementado e validado com capturas reais de relatórios.
- `claimInterface(force = true)` não existe na API pública Android. O app só pode solicitar o claim normal por `UsbDeviceConnection` depois da permissão USB.
- A Koda Engine shell/Binder não foi criada. Um APK comum não consegue se promover para UID 2000, conceder `INJECT_EVENTS`, acessar APIs ocultas ou persistir como daemon privilegiado apenas com um comando ADB genérico.
- Injeção global, roteamento por janela/InputChannel, deviceIds virtuais independentes, controle de VBUS e observador global de processos não estão implementados.
- Os controles de rotação, filtros, curva, destino e bindings são estado de interface nesta versão; ainda não alteram eventos HID reais.
- A lista de apps de destino e o modo Coop ainda não monitoram processos de terceiros.
- O serviço foreground está declarado, mas o streaming USB contínuo ainda não foi conectado. A inicialização de FGS deve ser feita em resposta a ação explícita do usuário e validada por versão do Android/OEM.

## Próxima etapa recomendada

Começar pela captura e documentação de relatórios USB/HID reais da Ugee S640 (VID `28BD`, PID `0914`), implementar parser com testes de fixtures e só depois conectar transformação de coordenadas e leitura contínua. A camada de privilégio shell deve ser projetada como componente separado, com protocolo mínimo autenticado e análise de compatibilidade/segurança por versão Android; não se deve prometer injeção global em aparelhos sem suporte real.
