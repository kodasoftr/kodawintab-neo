package com.koda.wintab

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tablet
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.koda.wintab.driver.UsbDeviceInfo
import com.koda.wintab.driver.UsbTabletRepository
import com.koda.wintab.service.UsbDriverService

private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF131F31)
private val Panel2 = Color(0xFF1B2A40)
private val Mint = Color(0xFF55D6C2)
private val Muted = Color(0xFF9BAEC3)
private val White = Color(0xFFEAF2FA)

private enum class Screen { ACTIVATION, HOME, TABLET, HUB, COOP, ARCHITECTURE }

class MainActivity : ComponentActivity() {
    private lateinit var usbRepository: UsbTabletRepository
    private var refreshUsb by mutableIntStateOf(0)
    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { refreshUsb++ }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbRepository = UsbTabletRepository(this)
        val permissionFilter = IntentFilter("com.koda.wintab.USB_PERMISSION")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbPermissionReceiver, permissionFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(usbPermissionReceiver, permissionFilter)
        }
        setContent {
            KodaTheme {
                KodaApp(
                    activity = this,
                    usbRepository = usbRepository,
                    refreshKey = refreshUsb,
                    onRefreshUsb = { refreshUsb++ }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::usbRepository.isInitialized) refreshUsb++
    }

    override fun onDestroy() {
        try { unregisterReceiver(usbPermissionReceiver) } catch (_: IllegalArgumentException) { }
        super.onDestroy()
    }
}

@Composable
private fun KodaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Mint,
            secondary = Color(0xFF85A9FF),
            background = Bg,
            surface = Panel,
            onPrimary = Bg,
            onBackground = White,
            onSurface = White
        ), content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KodaApp(
    activity: ComponentActivity,
    usbRepository: UsbTabletRepository,
    refreshKey: Int,
    onRefreshUsb: () -> Unit
) {
    var screen by remember { mutableStateOf(Screen.ACTIVATION) }
    var engineChecked by remember { mutableStateOf(false) }
    var engineActive by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Tablet") }
    var rotation by remember { mutableIntStateOf(0) }
    var invertX by remember { mutableStateOf(false) }
    var invertY by remember { mutableStateOf(false) }
    var autoRotate by remember { mutableStateOf(true) }
    var pressure by remember { mutableFloatStateOf(0.65f) }
    var smoothing by remember { mutableStateOf(false) }
    var selectedOutput by remember { mutableStateOf("Tela interna") }
    var selectedTarget by remember { mutableStateOf("ibisPaint X") }
    var message by remember { mutableStateOf<String?>(null) }
    val usbDevices = remember(refreshKey) { usbRepository.listDevices() }

    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("KODA WINTAB", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp, fontSize = 17.sp)
                        Text("ANDROID · DRIVER WORKSPACE", color = Muted, fontSize = 9.sp, letterSpacing = 1.3.sp)
                    }
                },
                navigationIcon = {
                    if (screen != Screen.ACTIVATION && screen != Screen.HOME) {
                        IconButton(onClick = { screen = Screen.HOME }) { Icon(Icons.Default.ArrowBack, null, tint = White) }
                    } else { Icon(Icons.Default.TabletAndroid, null, tint = Mint, modifier = Modifier.padding(horizontal = 14.dp)) }
                },
                actions = { },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = White)
            )
        },
        bottomBar = {
            if (screen != Screen.ACTIVATION) {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = screen == Screen.HOME, onClick = { screen = Screen.HOME }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Início") })
                    NavigationBarItem(selected = screen == Screen.TABLET, onClick = { screen = Screen.TABLET }, icon = { Icon(Icons.Default.TabletAndroid, null) }, label = { Text("Mesa") })
                    NavigationBarItem(selected = screen == Screen.HUB, onClick = { screen = Screen.HUB }, icon = { Icon(Icons.Default.Devices, null) }, label = { Text("Hub") })
                    NavigationBarItem(selected = screen == Screen.COOP, onClick = { screen = Screen.COOP }, icon = { Icon(Icons.Default.Computer, null) }, label = { Text("Coop") })
                }
            }
        },
        snackbarHost = { SnackbarHost(hostState = remember { SnackbarHostState() }) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                Screen.ACTIVATION -> ActivationScreen(
                    engineActive = engineActive,
                    engineChecked = engineChecked,
                    onCheck = { engineChecked = true; engineActive = false; message = "Koda Engine não encontrada. A ativação shell ainda não está implementada." },
                    onContinue = { screen = Screen.HOME }
                )
                Screen.HOME -> HomeScreen(
                    engineActive = engineActive,
                    tabletCount = usbDevices.count { it.likelyTablet },
                    usbCount = usbDevices.size,
                    onTablet = { screen = Screen.TABLET },
                    onHub = { screen = Screen.HUB },
                    onActivation = { screen = Screen.ACTIVATION },
                    onArchitecture = { screen = Screen.ARCHITECTURE }
                )
                Screen.TABLET -> TabletScreen(
                    devices = usbDevices,
                    selectedTab = selectedTab,
                    onTab = { selectedTab = it },
                    rotation = rotation,
                    onRotation = { rotation = it },
                    invertX = invertX,
                    onInvertX = { invertX = it },
                    invertY = invertY,
                    onInvertY = { invertY = it },
                    autoRotate = autoRotate,
                    onAutoRotate = { autoRotate = it },
                    pressure = pressure,
                    onPressure = { pressure = it },
                    smoothing = smoothing,
                    onSmoothing = { smoothing = it },
                    selectedOutput = selectedOutput,
                    onOutput = { selectedOutput = it },
                    selectedTarget = selectedTarget,
                    onTarget = { selectedTarget = it },
                    repository = usbRepository,
                    activity = activity,
                    onRefresh = onRefreshUsb
                )
                Screen.HUB -> HubScreen(devices = usbDevices, repository = usbRepository, activity = activity, onRefresh = onRefreshUsb, onCoop = { screen = Screen.COOP })
                Screen.COOP -> CoopScreen(devices = usbDevices)
                Screen.ARCHITECTURE -> ArchitectureScreen()
            }
            message?.let { msg ->
                Text(msg, color = Color(0xFFFFD27D), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().background(Panel2).padding(12.dp))
            }
        }
    }
}

@Composable
private fun ActivationScreen(engineActive: Boolean, engineChecked: Boolean, onCheck: () -> Unit, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Spacer(Modifier.height(10.dp))
        Box(Modifier.size(76.dp).background(Panel2, RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Security, null, tint = Mint, modifier = Modifier.size(38.dp))
        }
        Text("Ativação da Koda Engine", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = White)
        Text("Conecte os recursos USB e configure o ambiente de execução.", color = Muted)
        StatusCard("Koda Engine", if (engineActive) "Ativa" else "Não conectada", engineActive)
        if (engineChecked) Text("Verificação concluída: nenhum serviço Koda Engine foi localizado. O app continua em modo de configuração.", color = Color(0xFFFFD27D), fontSize = 13.sp)
        SectionTitle("Ativação via ADB")
        Text("O protótipo original descrevia um servidor shell próprio. Um APK comum não consegue criar um processo UID 2000 persistente nem conceder INJECT_EVENTS sozinho. Esta tela não simula uma ativação bem-sucedida.", color = Muted, fontSize = 13.sp)
        CodeCard("adb shell appops set com.koda.wintab GET_USAGE_STATS allow", "Comando auxiliar: habilita estatística de uso, não libera injeção global de eventos.")
        Button(onClick = onCheck, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Verificar conexão") }
        OutlinedButton(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text("Entrar no Koda Wintab") }
        Text("Modo local: a navegação e as configurações funcionam sem engine. Recursos privilegiados permanecem bloqueados até existir um serviço autorizado.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun HomeScreen(engineActive: Boolean, tabletCount: Int, usbCount: Int, onTablet: () -> Unit, onHub: () -> Unit, onActivation: () -> Unit, onArchitecture: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Seu espaço de trabalho", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Driver USB/HID para mesas digitalizadoras e periféricos.", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("USB", usbCount.toString(), "detectados", Modifier.weight(1f))
            MetricCard("Mesas", tabletCount.toString(), "prováveis", Modifier.weight(1f))
            MetricCard("Engine", if (engineActive) "ON" else "OFF", "shell", Modifier.weight(1f))
        }
        MainActionCard("Mesa", "Configurar mesa digitalizadora", Icons.Default.TabletAndroid, onTablet)
        MainActionCard("Hub", "Gerenciar mouse, teclado e mesas", Icons.Default.Devices, onHub)
        SectionTitle("Sistema")
        OutlinedButton(onClick = onActivation, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Security, null); Spacer(Modifier.width(8.dp)); Text("Ativação e permissões") }
        OutlinedButton(onClick = onArchitecture, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Info, null); Spacer(Modifier.width(8.dp)); Text("Arquitetura e limitações") }
        Text("Nenhum dispositivo fictício é exibido. Os contadores vêm da enumeração USB do Android.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun TabletScreen(
    devices: List<UsbDeviceInfo>, selectedTab: String, onTab: (String) -> Unit,
    rotation: Int, onRotation: (Int) -> Unit, invertX: Boolean, onInvertX: (Boolean) -> Unit,
    invertY: Boolean, onInvertY: (Boolean) -> Unit, autoRotate: Boolean, onAutoRotate: (Boolean) -> Unit,
    pressure: Float, onPressure: (Float) -> Unit, smoothing: Boolean, onSmoothing: (Boolean) -> Unit,
    selectedOutput: String, onOutput: (String) -> Unit, selectedTarget: String, onTarget: (String) -> Unit,
    repository: UsbTabletRepository, activity: ComponentActivity, onRefresh: () -> Unit
) {
    val tabs = listOf("Tablet", "Pen", "Bindings", "Filters", "Output")
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Text("Driver Global", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text("Detecção USB/HID · configuração local", color = Muted, fontSize = 12.sp)
        ScrollableTabRow(selectedTabIndex = tabs.indexOf(selectedTab), containerColor = Bg, contentColor = Mint, edgePadding = 0.dp) {
            tabs.forEach { tab -> Tab(selected = selectedTab == tab, onClick = { onTab(tab) }, text = { Text(tab) }) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (selectedTab) {
                "Tablet" -> {
                    SectionTitle("Dispositivos USB")
                    if (devices.isEmpty()) EmptyCard("Nenhum dispositivo USB conectado", "Conecte a mesa com um cabo OTG e atualize a lista.")
                    devices.forEach { UsbDeviceCard(it, onPermission = {
                        val intent = PendingIntent.getBroadcast(activity, it.device.deviceId, Intent("com.koda.wintab.USB_PERMISSION").setPackage(activity.packageName), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
                        repository.requestPermission(it.device, intent)
                        onRefresh()
                    }, onInspect = { repository.inspectRawDescriptor(it.device); onRefresh() }) }
                    Button(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Atualizar dispositivos") }
                    SectionTitle("Orientação e área")
                    SettingSwitch("Rotação automática", "Acompanhar a orientação da tela", autoRotate, onAutoRotate)
                    Text("Rotação manual", color = Muted)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(0, 90, 180, 270).forEach { angle -> FilterChip(selected = rotation == angle, onClick = { onRotation(angle) }, label = { Text("${angle}°") }) } }
                    SettingSwitch("Inverter eixo X", "Espelhar horizontalmente", invertX, onInvertX)
                    SettingSwitch("Inverter eixo Y", "Espelhar verticalmente", invertY, onInvertY)
                    Text("As opções acima são salvas apenas durante esta sessão nesta versão alpha; o mapeamento USB ativo ainda não aplica transformações ao fluxo HID.", color = Muted, fontSize = 11.sp)
                }
                "Pen" -> {
                    SectionTitle("Pressão da caneta")
                    Text("Curva de pressão demonstrativa", color = Muted)
                    Canvas(Modifier.fillMaxWidth().height(120.dp).background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
                        val pathPoints = listOf(0f to size.height, .25f to size.height * .60f, .75f to size.height * .22f, 1f to 0f)
                        for (i in 0 until pathPoints.lastIndex) drawLine(Mint, androidx.compose.ui.geometry.Offset(pathPoints[i].first * size.width, pathPoints[i].second), androidx.compose.ui.geometry.Offset(pathPoints[i+1].first * size.width, pathPoints[i+1].second), 4f)
                    }
                    Text("Sensibilidade ${"%.0f".format(pressure * 100)}%", color = White)
                    Slider(value = pressure, onValueChange = onPressure)
                    Text("O valor é uma pré-configuração visual; não altera pressão real sem parser HID e pipeline de saída.", color = Muted, fontSize = 11.sp)
                }
                "Bindings" -> {
                    SectionTitle("Atalhos da mesa")
                    listOf("K1 · Desfazer — Ctrl + Z", "K2 · Refazer — Ctrl + Y", "K3 · Pincel — B", "K4 · Borracha — E", "K5 · Zoom +", "K6 · Zoom −", "Caneta · Toque primário", "Botão 1 · Borracha").forEach { InfoRow(it, "Mapeamento de referência · ainda não enviado ao dispositivo") }
                }
                "Filters" -> {
                    SectionTitle("Filtros opcionais")
                    SettingSwitch("Suavização de pressão", "Desligado por padrão no driver real", smoothing, onSmoothing)
                    InfoRow("Anti-jitter", "Configuração futura · sem filtro aplicado no fluxo USB")
                    InfoRow("Compensação de tilt", "Aguardando parser com suporte a inclinação")
                    InfoRow("Histerese", "Aguardando implementação do pipeline")
                }
                "Output" -> {
                    SectionTitle("Saída")
                    Text("Tela de destino", color = Muted)
                    listOf("Tela interna", "Display externo", "Samsung DeX / modo desktop", "Espelhamento").forEach { item -> RadioSetting(item, selectedOutput == item) { onOutput(item) } }
                    Text("Aplicativo de destino", color = Muted)
                    listOf("ibisPaint X", "Krita", "Clip Studio Paint", "Infinite Painter", "Sistema (Coop)").forEach { item -> RadioSetting(item, selectedTarget == item) { onTarget(item) } }
                    InfoRow("Modo de saída", "Absoluto · modo de referência. Injeção global ainda não disponível.")
                }
            }
        }
    }
}

@Composable
private fun HubScreen(devices: List<UsbDeviceInfo>, repository: UsbTabletRepository, activity: ComponentActivity, onRefresh: () -> Unit, onCoop: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Hub de dispositivos", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Periféricos USB conectados ao Android", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onRefresh, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Refresh, null); Text(" Atualizar") }
            OutlinedButton(onClick = onCoop, modifier = Modifier.weight(1f)) { Text("Modo Coop") }
        }
        Spacer(Modifier.height(10.dp))
        if (devices.isEmpty()) EmptyCard("Hub vazio", "Nenhum mouse, teclado ou mesa USB foi enumerado.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(devices, key = { it.device.deviceId }) { device ->
                UsbDeviceCard(device, onPermission = {
                    val intent = PendingIntent.getBroadcast(activity, device.device.deviceId, Intent("com.koda.wintab.USB_PERMISSION").setPackage(activity.packageName), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
                    repository.requestPermission(device.device, intent)
                }, onInspect = { repository.inspectRawDescriptor(device.device); onRefresh() })
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("A API pública USB do Android não permite atribuir um deviceId virtual independente por app nem rotear eventos para janelas arbitrárias. Os controles avançados permanecem como especificação.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun CoopScreen(devices: List<UsbDeviceInfo>) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Modo Coop", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Cooperação global quando um destino fecha.", color = Muted)
        StatusCard("Estado atual", "Somente visualização", false)
        EmptyCard("Roteamento Coop não ativo", "A detecção de fechamento e a injeção independente por dispositivo exigem o serviço privilegiado Koda Engine, ainda não implementado.")
        SectionTitle("Dispositivos vistos pelo sistema")
        devices.forEach { InfoRow(it.displayName, "${it.vidPid} · deviceId ${it.device.deviceId}") }
        if (devices.isEmpty()) Text("Nenhum dispositivo conectado.", color = Muted)
    }
}

@Composable
private fun ArchitectureScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Arquitetura Android", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Base nativa criada a partir do protótipo React/TypeScript.", color = Muted)
        listOf(
            "Interface" to "Kotlin + Jetpack Compose + Material 3",
            "Plataforma" to "Android 10+ · minSdk 29 · targetSdk 34 · compileSdk 35",
            "USB Host" to "Enumeração, solicitação de permissão e leitura do tamanho de rawDescriptors",
            "Serviço" to "Foreground Service conectado declarado; streaming contínuo ainda não implementado",
            "Parser HID" to "Não implementado. Perfis de VID/PID ainda precisam de validação com relatórios reais",
            "Koda Engine" to "Não implementada. Binder shell, INJECT_EVENTS e persistência UID 2000 não são concedidos por um APK comum",
            "Multi-display" to "Seleção visual disponível; roteamento por InputChannel não implementado",
            "Modo Coop" to "Tela de estado; detecção global de processos ainda não implementada"
        ).forEach { InfoRow(it.first, it.second) }
        SectionTitle("Próximas etapas técnicas")
        listOf("Validar Ugee S640 com captura HID real", "Implementar parsers por modelo e testes de pacote", "Projetar serviço auxiliar shell assinado e canal Binder autenticado", "Implementar transformação de coordenadas e curva de pressão", "Validar injeção apenas em ambiente autorizado e hardware real").forEachIndexed { i, item -> InfoRow("${i + 1}. $item", "Pendente") }
    }
}

@Composable
private fun UsbDeviceCard(info: UsbDeviceInfo, onPermission: () -> Unit, onInspect: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (info.likelyTablet) Icons.Default.TabletAndroid else Icons.Default.Devices, null, tint = Mint)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(info.displayName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${info.vidPid} · ${info.interfaceCount} interface(s)", color = Muted, fontSize = 11.sp)
                }
                Box(Modifier.size(8.dp).background(if (info.hasPermission) Mint else Color(0xFFFFC36B), CircleShape))
            }
            Text(if (info.likelyTablet) "Possível mesa / dispositivo HID" else "Periférico USB", color = Muted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onPermission, modifier = Modifier.weight(1f)) { Text(if (info.hasPermission) "Permissão concedida" else "Solicitar acesso", fontSize = 11.sp) }
                OutlinedButton(onClick = onInspect, modifier = Modifier.weight(1f)) { Text("Inspecionar", fontSize = 11.sp) }
            }
        }
    }
}

@Composable private fun MainActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).background(Panel2, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Mint, modifier = Modifier.size(28.dp)) }
            Spacer(Modifier.width(15.dp))
            Column(Modifier.weight(1f)) { Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 12.sp) }
            Text("›", color = Mint, fontSize = 30.sp)
        }
    }
}

@Composable private fun MetricCard(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) { Text(title, color = Muted, fontSize = 10.sp); Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text(caption, color = Muted, fontSize = 9.sp) }
    }
}

@Composable private fun StatusCard(title: String, status: String, active: Boolean) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (active) Icons.Default.CheckCircle else Icons.Default.Info, null, tint = if (active) Mint else Color(0xFFFFC36B))
            Spacer(Modifier.width(10.dp)); Column { Text(title, fontWeight = FontWeight.SemiBold); Text(status, color = Muted, fontSize = 12.sp) }
        }
    }
}

@Composable private fun SectionTitle(text: String) { Text(text.uppercase(), color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp) }
@Composable private fun EmptyCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { Text(title, fontWeight = FontWeight.SemiBold); Text(body, color = Muted, fontSize = 12.sp) }
    }
}
@Composable private fun InfoRow(title: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text(detail, color = Muted, fontSize = 11.sp) }
    }
}
@Composable private fun CodeCard(code: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(code, color = Mint, fontSize = 11.sp); Text(description, color = Muted, fontSize = 11.sp) }
    }
}
@Composable private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text(subtitle, color = Muted, fontSize = 10.sp) }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
@Composable private fun RadioSetting(title: String, selected: Boolean, onSelect: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onSelect).padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected, onClick = onSelect); Text(title, fontSize = 13.sp) }
}
