package com.koda.wintab.driver

import kotlin.math.pow

/** Pure coordinate and pressure helpers; these are not connected to USB event injection yet. */
data class NormalizedPoint(val x: Float, val y: Float)

object TabletMath {
    fun transform(
        rawX: Float,
        rawY: Float,
        maxX: Float,
        maxY: Float,
        rotation: Int = 0,
        invertX: Boolean = false,
        invertY: Boolean = false
    ): NormalizedPoint {
        require(maxX > 0f && maxY > 0f) { "Raw coordinate bounds must be positive" }
        var x = (rawX / maxX).coerceIn(0f, 1f)
        var y = (rawY / maxY).coerceIn(0f, 1f)
        if (invertX) x = 1f - x
        if (invertY) y = 1f - y
        return when (((rotation % 360) + 360) % 360) {
            0 -> NormalizedPoint(x, y)
            90 -> NormalizedPoint(1f - y, x)
            180 -> NormalizedPoint(1f - x, 1f - y)
            270 -> NormalizedPoint(y, 1f - x)
            else -> throw IllegalArgumentException("Rotation must be 0, 90, 180 or 270 degrees")
        }
    }

    fun applyPressureCurve(value: Float, maxValue: Float, curve: String = "linear"): Float {
        require(maxValue > 0f) { "maxValue must be positive" }
        val x = (value / maxValue).coerceIn(0f, 1f)
        val y = when (curve.lowercase()) {
            "soft" -> x.pow(0.72f)
            "firm" -> x.pow(1.35f)
            "aggressive" -> x.pow(0.55f)
            else -> x
        }
        return y * maxValue
    }

    private fun Float.pow(exponent: Float): Float = this.toDouble().pow(exponent.toDouble()).toFloat()
}
