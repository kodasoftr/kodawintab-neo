package com.koda.wintab.driver

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.hardware.usb.UsbConstants
import java.util.Locale

data class UsbDeviceInfo(
    val device: UsbDevice,
    val displayName: String,
    val vendorId: Int,
    val productId: Int,
    val interfaceCount: Int,
    val hasPermission: Boolean,
    val likelyTablet: Boolean
) {
    val vidPid: String get() = "%04X:%04X".format(Locale.US, vendorId, productId)
}

class UsbTabletRepository(context: Context) {
    private val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    fun listDevices(): List<UsbDeviceInfo> = manager.deviceList.values.map { device ->
        val hasDigitizer = (0 until device.interfaceCount).any { index ->
            val intf = device.getInterface(index)
            intf.interfaceClass == 0x03 || intf.interfaceSubclass == 0x01
        }
        UsbDeviceInfo(
            device = device,
            displayName = device.productName?.takeIf { it.isNotBlank() } ?: "Dispositivo USB",
            vendorId = device.vendorId,
            productId = device.productId,
            interfaceCount = device.interfaceCount,
            hasPermission = manager.hasPermission(device),
            likelyTablet = hasDigitizer || device.deviceClass == 0x03
        )
    }.sortedByDescending { it.likelyTablet }

    fun requestPermission(device: UsbDevice, pendingIntent: android.app.PendingIntent) {
        manager.requestPermission(device, pendingIntent)
    }

    /** Opens the device only after Android has granted USB permission. No forced claim is attempted. */
    fun inspectRawDescriptor(device: UsbDevice): Int? {
        if (!manager.hasPermission(device)) return null
        val connection = manager.openDevice(device) ?: return null
        return try { connection.rawDescriptors?.size } finally { connection.close() }
    }

    fun openDevice(device: UsbDevice) = if (manager.hasPermission(device)) manager.openDevice(device) else null
}
