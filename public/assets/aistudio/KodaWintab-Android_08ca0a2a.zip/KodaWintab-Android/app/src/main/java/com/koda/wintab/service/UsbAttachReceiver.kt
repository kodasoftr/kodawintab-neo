package com.koda.wintab.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class UsbAttachReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // USB enumeration is refreshed when the user opens the Hub or Tablet screen.
        // No background privilege escalation or silent device access is attempted.
    }
}
