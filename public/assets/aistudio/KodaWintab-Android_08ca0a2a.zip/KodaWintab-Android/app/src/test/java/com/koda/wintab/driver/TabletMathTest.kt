package com.koda.wintab.driver

import org.junit.Assert.assertEquals
import org.junit.Test

class TabletMathTest {
    @Test fun identityTransformKeepsNormalizedCoordinates() {
        val point = TabletMath.transform(250f, 500f, 1000f, 1000f)
        assertEquals(0.25f, point.x, 0.0001f)
        assertEquals(0.5f, point.y, 0.0001f)
    }

    @Test fun rotationNinetyDegreesRotatesNormalizedCoordinates() {
        val point = TabletMath.transform(250f, 500f, 1000f, 1000f, rotation = 90)
        assertEquals(0.5f, point.x, 0.0001f)
        assertEquals(0.25f, point.y, 0.0001f)
    }

    @Test fun invertedAxesMirrorCoordinates() {
        val point = TabletMath.transform(250f, 500f, 1000f, 1000f, invertX = true, invertY = true)
        assertEquals(0.75f, point.x, 0.0001f)
        assertEquals(0.5f, point.y, 0.0001f)
    }

    @Test fun pressureOutputStaysWithinNativeRange() {
        val value = TabletMath.applyPressureCurve(9000f, 8192f, "firm")
        assertEquals(8192f, value, 0.0001f)
    }
}
