import React, { useState, useEffect } from 'react';
import { 
  ActiveView, 
  TabletDevice, 
  TabletConfig, 
  HubDevice, 
  KodaEngineStatus 
} from './types/koda';
import { 
  SUPPORTED_TABLETS, 
  DEFAULT_TABLET_CONFIG 
} from './data/tabletProfiles';
import { Navbar } from './components/Navbar';
import { HomeView } from './components/HomeView';
import { ActivationView } from './components/ActivationView';
import { TabletDriverView } from './components/TabletDriverView';
import { HubView } from './components/HubView';
import { CoopModeView } from './components/CoopModeView';
import { ArchitectureView } from './components/ArchitectureView';
import { VmTestingView } from './components/VmTestingView';

export default function App() {
  const [currentView, setCurrentView] = useState<ActiveView>('home');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);

  // Koda Engine privileged status
  const [engineStatus, setEngineStatus] = useState<KodaEngineStatus>({
    isActive: true,
    uid: 2000,
    pid: 14820,
    sessionToken: 'koda_sec_7f9c2d18e4b0',
    uptimeSeconds: 3840,
    injectEventsPermission: true,
    windowManagerAccess: true,
    vbusControlActive: true,
    claimInterfaceForced: true,
    displayManagerAccess: true,
    processObserverRegistered: true,
    rebootPersistence: true,
  });

  // Selected tablet and its OpenTabletDriver config
  const [activeTablet, setActiveTablet] = useState<TabletDevice>(SUPPORTED_TABLETS[0]); // Ugee S640 default
  const [tabletConfig, setTabletConfig] = useState<TabletConfig>(DEFAULT_TABLET_CONFIG);

  // Multi-Device Hub state
  const [hubDevices, setHubDevices] = useState<HubDevice[]>([
    {
      id: 'm1',
      slot: 'mouse1',
      name: 'Mouse 1 (Físico)',
      hardwareName: 'Logitech G Pro Wireless (0x046D)',
      type: 'mouse',
      deviceId: 101,
      targetApp: 'ibisPaint X',
      isCoop: false,
      cursorIcon: 'crosshair',
      cursorHotspot: [8, 8],
    },
    {
      id: 'm2',
      slot: 'mouse2',
      name: 'Mouse 2 (Físico)',
      hardwareName: 'Razer Viper V2 Pro (0x1532)',
      type: 'mouse',
      deviceId: 102,
      targetApp: 'Google Chrome',
      isCoop: false,
      cursorIcon: 'default_arrow',
      cursorHotspot: [0, 0],
    },
    {
      id: 'k1',
      slot: 'keyboard1',
      name: 'Teclado 1 (Físico)',
      hardwareName: 'Keychron K2 Mechanical (0x3434)',
      type: 'keyboard',
      deviceId: 201,
      targetApp: 'ibisPaint X',
      isCoop: false,
    },
    {
      id: 'k2',
      slot: 'keyboard2',
      name: 'Teclado 2 (Físico)',
      hardwareName: 'Anne Pro 2 Wireless (0x04D9)',
      type: 'keyboard',
      deviceId: 202,
      targetApp: 'Termux (Terminal)',
      isCoop: false,
    },
    {
      id: 't1',
      slot: 'mesa1',
      name: 'Mesa 1 (Física)',
      hardwareName: 'Ugee S640 Stylus (0x28BD:0x0914)',
      type: 'tablet',
      deviceId: 301,
      targetApp: 'ibisPaint X',
      isCoop: false,
    },
    {
      id: 't2',
      slot: 'mesa2',
      name: 'Mesa 2 (Física)',
      hardwareName: 'Wacom One DTC133 (0x056A:0x03A6)',
      type: 'tablet',
      deviceId: 302,
      targetApp: 'Krita for Android',
      isCoop: false,
    },
  ]);

  // Synchronize document dark class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  return (
    <div className={`min-h-screen flex flex-col ${isDarkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {/* Top Bar Header */}
      <Navbar
        currentView={currentView}
        onNavigate={setCurrentView}
        isEngineActive={engineStatus.isActive}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
      />

      {/* Main Content Viewport */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomeView
            onNavigate={setCurrentView}
            activeTablet={activeTablet}
            hubDevices={hubDevices}
            engineStatus={engineStatus}
            targetDisplay={tabletConfig.targetDisplay}
          />
        )}

        {currentView === 'activation' && (
          <ActivationView
            engineStatus={engineStatus}
            setEngineStatus={setEngineStatus}
            onEnterApp={() => setCurrentView('home')}
          />
        )}

        {currentView === 'tablet' && (
          <TabletDriverView
            activeTablet={activeTablet}
            setActiveTablet={setActiveTablet}
            config={tabletConfig}
            setConfig={setTabletConfig}
            onOpenCoopMode={() => setCurrentView('coop')}
          />
        )}

        {currentView === 'hub' && (
          <HubView
            hubDevices={hubDevices}
            setHubDevices={setHubDevices}
            onOpenCoopMode={() => setCurrentView('coop')}
          />
        )}

        {currentView === 'coop' && (
          <CoopModeView
            hubDevices={hubDevices}
            setHubDevices={setHubDevices}
          />
        )}

        {currentView === 'architecture' && <ArchitectureView />}

        {currentView === 'vm_testing' && <VmTestingView />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-8 px-4 sm:px-6 lg:px-8 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">Koda Wintab</span>
            <span aria-hidden="true">·</span>
            <span>Aplicativo Android Nativo (100% Kotlin)</span>
            <span aria-hidden="true">·</span>
            <span>minSdk 29 · targetSdk 34</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => setCurrentView('activation')}
              className="hover:text-cyan-400 transition-colors"
            >
              Comando ADB
            </button>
            <button
              onClick={() => setCurrentView('architecture')}
              className="hover:text-cyan-400 transition-colors"
            >
              Arquitetura Kotlin
            </button>
            <button
              onClick={() => setCurrentView('vm_testing')}
              className="hover:text-cyan-400 transition-colors"
            >
              Validação VM
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
