import React, { useState } from 'react';
import { KodaEngineStatus, ActiveView } from '../types/koda';
import { 
  Terminal, 
  Copy, 
  Check, 
  ShieldCheck, 
  ShieldAlert, 
  RefreshCw, 
  ArrowRight, 
  Cpu, 
  CheckCircle2, 
  Zap, 
  HelpCircle,
  RotateCcw
} from 'lucide-react';

interface ActivationViewProps {
  engineStatus: KodaEngineStatus;
  setEngineStatus: React.Dispatch<React.SetStateAction<KodaEngineStatus>>;
  onEnterApp: () => void;
}

export const ActivationView: React.FC<ActivationViewProps> = ({
  engineStatus,
  setEngineStatus,
  onEnterApp,
}) => {
  const [copied, setCopied] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifyLog, setVerifyLog] = useState<string[]>([]);

  const adbCommand = `adb shell "nohup sh -c 'CLASSPATH=$(pm path com.koda.wintab | cut -d: -f2 | tr -d \\'\\r\\') app_process /system/bin com.koda.wintab.engine.KodaServer' > /dev/null 2>&1 &"`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(adbCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleVerify = () => {
    setIsVerifying(true);
    setVerifyLog([
      'Conectando ao daemon local do KodaServer via Binder IPC...',
      'Verificando UID do processo (esperado: 2000 shell)...',
    ]);

    setTimeout(() => {
      setVerifyLog((prev) => [
        ...prev,
        'UID confirmado: 2000 (Shell privilegiado do Android)',
        'Permissão android.permission.INJECT_EVENTS: CONCEDIDA',
        'Canal IWindowManager & InputChannel: ACESSÍVEL',
        'VBUS Power Management: HABILITADO',
        'Koda Engine sincronizada com sucesso!',
      ]);
      setEngineStatus((prev) => ({
        ...prev,
        isActive: true,
        pid: 14820,
        injectEventsPermission: true,
        windowManagerAccess: true,
        vbusControlActive: true,
        claimInterfaceForced: true,
        displayManagerAccess: true,
        processObserverRegistered: true,
      }));
      setIsVerifying(false);
    }, 1000);
  };

  const handleSimulateDeactivate = () => {
    setEngineStatus((prev) => ({
      ...prev,
      isActive: false,
    }));
    setVerifyLog(['Engine desativada para teste de recuperação.']);
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      {/* Title & context */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-xs text-cyan-400 font-medium mb-1">
          <span>Koda Engine v1.0</span>
          <span aria-hidden="true">·</span>
          <span>Engine Própria Integrada ao APK</span>
          <span aria-hidden="true">·</span>
          <span>Sem Shizuku / Sem Root</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Ativação de Privilégio Shell
        </h1>
        <p className="mt-2 text-sm text-slate-400 leading-relaxed max-w-2xl">
          O Koda Wintab utiliza uma engine nativa com UID 2000 (shell) para injeção global de eventos
          com precisão de nível PC, roteamento de múltiplos dispositivos e coordenação de USB Host.
          A ativação é realizada apenas uma vez via computador e permanece ativa offline.
        </p>
      </div>

      {/* Status Banner */}
      <div
        className={`p-5 rounded-xl border transition-all mb-8 ${
          engineStatus.isActive
            ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200'
            : 'bg-slate-900 border-slate-800 text-slate-200'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div
              className={`p-3 rounded-lg border ${
                engineStatus.isActive
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
              }`}
            >
              {engineStatus.isActive ? (
                <ShieldCheck className="w-6 h-6" />
              ) : (
                <ShieldAlert className="w-6 h-6" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-semibold text-white">
                  Status da Koda Engine: {engineStatus.isActive ? 'Ativa e Operacional' : 'Aguardando Ativação'}
                </h2>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {engineStatus.isActive
                  ? `Servidor IPC respondendo no PID ${engineStatus.pid} com UID 2000. Privilégios INJECT_EVENTS garantidos.`
                  : 'Execute o comando ADB abaixo via computador (cabo USB ou Wi-Fi) para iniciar o daemon.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {engineStatus.isActive ? (
              <>
                <button
                  onClick={handleSimulateDeactivate}
                  title="Simular queda da engine para testar recuperação"
                  className="px-3 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 border border-slate-800 rounded-lg hover:bg-slate-900 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5 inline mr-1" />
                  Testar Reinício
                </button>
                <button
                  onClick={onEnterApp}
                  className="px-5 py-2.5 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-lg shadow-cyan-950/50 flex items-center gap-2 transition-all"
                >
                  <span>Entrar no Koda Wintab</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </>
            ) : (
              <button
                onClick={handleVerify}
                disabled={isVerifying}
                className="px-4 py-2.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg flex items-center gap-2 transition-all disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
                <span>{isVerifying ? 'Verificando...' : 'Verificar Conexão'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Step by step ADB guide */}
      <div className="space-y-6">
        <div className="border border-slate-800 rounded-xl bg-slate-900/60 p-6">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span>Passo a Passo de Ativação Rápida (Única Vez)</span>
          </h3>

          <ol className="space-y-4 text-xs text-slate-300">
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold shrink-0">
                1
              </span>
              <div>
                <strong className="text-white">Depuração USB:</strong> No seu celular ou tablet Android,
                vá em <span className="text-cyan-300">Configurações &gt; Opções do desenvolvedor</span> e ative
                a <em>Depuração USB</em>.
              </div>
            </li>
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold shrink-0">
                2
              </span>
              <div>
                <strong className="text-white">Conexão ADB:</strong> Conecte o aparelho ao PC via cabo USB
                ou utilize <code>adb connect &lt;ip&gt;:5555</code> para conexão Wi-Fi.
              </div>
            </li>
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold shrink-0">
                3
              </span>
              <div>
                <strong className="text-white">Copie e execute o comando:</strong> Cole a linha de comando abaixo
                no terminal (PowerShell, CMD, Bash ou Terminal do Mac/Linux):
              </div>
            </li>
          </ol>

          {/* Code box */}
          <div className="mt-4 relative group">
            <pre className="p-4 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-cyan-300 overflow-x-auto whitespace-pre-wrap break-all select-all leading-relaxed">
              {adbCommand}
            </pre>
            <button
              onClick={copyToClipboard}
              className="absolute top-3 right-3 px-2.5 py-1.5 rounded-md bg-slate-800/90 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 border border-slate-700 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copiar Comando</span>
                </>
              )}
            </button>
          </div>

          <div className="mt-4 flex items-center justify-between pt-4 border-t border-slate-800/80">
            <span className="text-xs text-slate-400">
              Pronto após executar no terminal?
            </span>
            <button
              onClick={handleVerify}
              disabled={isVerifying}
              className="px-4 py-2 text-xs font-semibold text-cyan-400 hover:text-cyan-300 bg-cyan-950/30 hover:bg-cyan-900/40 border border-cyan-500/40 rounded-lg flex items-center gap-2 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
              <span>Verificar Conexão Agora</span>
            </button>
          </div>
        </div>

        {/* Verification logs output */}
        {verifyLog.length > 0 && (
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
            <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
              Log de Inicialização da Engine
            </div>
            <div className="space-y-1 text-xs font-mono text-slate-300">
              {verifyLog.map((line, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <span className="text-slate-600 select-none">&gt;</span>
                  <span className={line.includes('sucesso') || line.includes('CONCEDIDA') ? 'text-emerald-400' : ''}>
                    {line}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Capabilities card */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl border border-slate-800/80 bg-slate-900/40">
            <div className="flex items-center gap-2 text-xs font-bold text-white mb-1">
              <Zap className="w-4 h-4 text-cyan-400" />
              <span>Injeção de Baixa Latência</span>
            </div>
            <p className="text-xs text-slate-400">
              <code>InputManager.injectInputEvent</code> em modo assíncrono para pipeline de ~8ms (1 frame).
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-800/80 bg-slate-900/40">
            <div className="flex items-center gap-2 text-xs font-bold text-white mb-1">
              <Cpu className="w-4 h-4 text-indigo-400" />
              <span>Sem Root / Sem Shizuku</span>
            </div>
            <p className="text-xs text-slate-400">
              Engine 100% própria, integrada diretamente no APK com autenticação por token de sessão restrito.
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-800/80 bg-slate-900/40">
            <div className="flex items-center gap-2 text-xs font-bold text-white mb-1">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Persistência no Boot</span>
            </div>
            <p className="text-xs text-slate-400">
              Monitora <code>BOOT_COMPLETED</code> para re-conexão rápida e fallback instantâneo.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
