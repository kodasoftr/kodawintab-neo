import React, { useState } from 'react';
import { KOTLIN_ARCHITECTURE_FILES, KotlinSourceFile } from '../data/kotlinCode';
import { 
  Code2, 
  FileCode, 
  Copy, 
  Check, 
  Download, 
  FolderTree, 
  Layers, 
  Cpu, 
  Terminal, 
  ExternalLink,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

export const ArchitectureView: React.FC = () => {
  const [selectedFileId, setSelectedFileId] = useState<string>('koda_server');
  const [copied, setCopied] = useState<boolean>(false);

  const currentFile =
    KOTLIN_ARCHITECTURE_FILES.find((f) => f.id === selectedFileId) ||
    KOTLIN_ARCHITECTURE_FILES[0];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([currentFile.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = currentFile.filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
      {/* Title */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 mb-1">
          <span>Arquitetura Técnica</span>
          <span aria-hidden="true">·</span>
          <span>100% Kotlin Nativo</span>
          <span aria-hidden="true">·</span>
          <span>Android Studio &amp; Gradle (API 29–34)</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Código-Fonte e Componentes Nativos do Koda Wintab
        </h1>
        <p className="mt-2 text-sm text-slate-300 leading-relaxed max-w-3xl">
          Arquitetura modular de alta performance projetada para o Android Studio com Gradle padrão.
          Todos os arquivos estão prontos para compilação direta, respeitando os requisitos de
          Foreground Service (Android 10+), USB Host e injeção assíncrona.
        </p>
      </div>

      {/* Component Mapping Table (as specified in Section 7 of the user prompt) */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 mb-8">
        <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>Mapeamento de Componentes Android Nativos Utilizados</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950 text-slate-400 font-mono uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-4 font-semibold">Componente Android</th>
                <th className="py-2.5 px-4 font-semibold">Papel no Koda Wintab</th>
                <th className="py-2.5 px-4 font-semibold">Requisito de API</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-slate-300 font-sans">
              <tr className="hover:bg-slate-950/40">
                <td className="py-3 px-4 font-mono text-cyan-300 font-semibold">Activity</td>
                <td className="py-3 px-4">Tela de ativação, Home, Tela Mesa (OTD), Janela Hub em Jetpack Compose</td>
                <td className="py-3 px-4 font-mono text-slate-400">minSdk 29+</td>
              </tr>
              <tr className="hover:bg-slate-950/40">
                <td className="py-3 px-4 font-mono text-cyan-300 font-semibold">Foreground Service</td>
                <td className="py-3 px-4">Serviço Hub + Koda Server com tipo <code>connectedDevice</code> declarado</td>
                <td className="py-3 px-4 font-mono text-slate-400">Android 10 (API 29) e 14 (API 34)</td>
              </tr>
              <tr className="hover:bg-slate-950/40">
                <td className="py-3 px-4 font-mono text-cyan-300 font-semibold">BroadcastReceiver</td>
                <td className="py-3 px-4">Detecção de conexão/desconexão USB e reconfiguração de orientação de tela</td>
                <td className="py-3 px-4 font-mono text-slate-400">API 29+</td>
              </tr>
              <tr className="hover:bg-slate-950/40">
                <td className="py-3 px-4 font-mono text-cyan-300 font-semibold">USB Host API</td>
                <td className="py-3 px-4"><code>UsbManager</code>, <code>UsbDeviceConnection</code>, <code>claimInterface(force=true)</code></td>
                <td className="py-3 px-4 font-mono text-slate-400">API 29+</td>
              </tr>
              <tr className="hover:bg-slate-950/40">
                <td className="py-3 px-4 font-mono text-cyan-300 font-semibold">InputManager (Koda Engine)</td>
                <td className="py-3 px-4">Injeção global de eventos de toque/caneta via Binder IPC com UID 2000</td>
                <td className="py-3 px-4 font-mono text-slate-400">Shell UID 2000 (INJECT_EVENTS)</td>
              </tr>
              <tr className="hover:bg-slate-950/40">
                <td className="py-3 px-4 font-mono text-cyan-300 font-semibold">DisplayManager</td>
                <td className="py-3 px-4">Roteamento para Samsung DeX, Motorola Ready For, modo PC e monitores externos</td>
                <td className="py-3 px-4 font-mono text-slate-400">API 29+</td>
              </tr>
              <tr className="hover:bg-slate-950/40">
                <td className="py-3 px-4 font-mono text-cyan-300 font-semibold">PointerIcon API</td>
                <td className="py-3 px-4">Cursores personalizados (.png e .cur convertidos) com definição de hotspot</td>
                <td className="py-3 px-4 font-mono text-slate-400">API 24+</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Code Browser Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Tree List (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <FolderTree className="w-3.5 h-3.5 text-cyan-400" />
                <span>Arquivos do Projeto</span>
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                {KOTLIN_ARCHITECTURE_FILES.length} arquivos
              </span>
            </div>

            <div className="space-y-1">
              {KOTLIN_ARCHITECTURE_FILES.map((file) => (
                <button
                  key={file.id}
                  onClick={() => setSelectedFileId(file.id)}
                  className={`w-full p-2.5 rounded-lg text-left text-xs transition-colors flex items-center justify-between ${
                    selectedFileId === file.id
                      ? 'bg-cyan-500/10 text-cyan-300 font-semibold border border-cyan-500/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-950'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className="w-4 h-4 shrink-0 text-cyan-400" />
                    <span className="truncate">{file.filename}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase shrink-0">
                    {file.language}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Info Box */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
            <div className="font-semibold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Compatibilidade Garantida</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              O código implementa o padrão de tipo de serviço de primeiro plano exigido a partir do
              Android 10 (API 29) e validado com os requisitos estritos do Android 14 (API 34).
            </p>
          </div>
        </div>

        {/* Right Code Display (8 cols) */}
        <div className="lg:col-span-8 flex flex-col rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
          {/* File Header Bar */}
          <div className="p-4 bg-slate-950 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-xs font-mono text-cyan-400 font-semibold">{currentFile.path}</div>
              <div className="text-xs text-slate-400 mt-0.5">{currentFile.description}</div>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                onClick={handleCopyCode}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Código</span>
                  </>
                )}
              </button>

              <button
                onClick={handleDownloadFile}
                className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 border border-cyan-500/40 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Baixar</span>
              </button>
            </div>
          </div>

          {/* Code Viewer */}
          <div className="p-4 bg-slate-950/80 overflow-x-auto max-h-[580px] overflow-y-auto">
            <pre className="text-xs font-mono text-slate-200 leading-relaxed selection:bg-cyan-500/30">
              {currentFile.code}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
