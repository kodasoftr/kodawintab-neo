import React, { useState, useRef } from 'react';
import { HubDevice, TargetApplication } from '../types/koda';
import { TARGET_APPLICATIONS } from '../data/tabletProfiles';
import { 
  Users, 
  Layers, 
  Mouse, 
  PenTool, 
  AlertTriangle, 
  CheckCircle2, 
  Play, 
  RotateCcw, 
  ShieldCheck, 
  Activity, 
  Cpu, 
  ExternalLink,
  Sparkles
} from 'lucide-react';

interface CoopModeViewProps {
  hubDevices: HubDevice[];
  setHubDevices: React.Dispatch<React.SetStateAction<HubDevice[]>>;
}

export const CoopModeView: React.FC<CoopModeViewProps> = ({
  hubDevices,
  setHubDevices,
}) => {
  const [closedApps, setClosedApps] = useState<string[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Dual pointer canvas test
  const [pointer1Pos, setPointer1Pos] = useState({ x: 120, y: 90 });
  const [pointer2Pos, setPointer2Pos] = useState({ x: 280, y: 150 });
  const [activeTrail, setActiveTrail] = useState<{ x: number; y: number; dev: string }[]>([]);

  const handleSimulateCloseApp = (appName: string) => {
    if (closedApps.includes(appName)) return;
    const nextClosed = [...closedApps, appName];
    setClosedApps(nextClosed);

    // Set devices mapped to this app to Coop mode
    setHubDevices((prev) =>
      prev.map((d) => (d.targetApp === appName ? { ...d, isCoop: true } : d))
    );

    setToastMessage(`App fechado (${appName}) — dispositivos vinculados entraram em Modo Coop!`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleReopenApp = (appName: string) => {
    setClosedApps((prev) => prev.filter((a) => a !== appName));
    setHubDevices((prev) =>
      prev.map((d) => (d.targetApp === appName ? { ...d, isCoop: false } : d))
    );
    setToastMessage(`App reaberto (${appName}) — dispositivos retornaram ao modo Roteado.`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleResetAll = () => {
    setClosedApps([]);
    setHubDevices((prev) => prev.map((d) => ({ ...d, isCoop: false })));
    setToastMessage('Todos os aplicativos restaurados. Dispositivos roteados.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Dual pointer moving simulation
  const handleTestMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setPointer1Pos({ x, y });
    setPointer2Pos({
      x: Math.max(20, Math.min(rect.width - 20, rect.width - x)),
      y: Math.max(20, Math.min(rect.height - 20, rect.height - y)),
    });

    setActiveTrail((prev) => [
      { x, y, dev: 'Mouse 1 (ID 101)' },
      { x: rect.width - x, y: rect.height - y, dev: 'Mouse 2 (ID 102)' },
      ...prev.slice(0, 18),
    ]);
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
      {/* Toast alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-cyan-950 border border-cyan-500 text-cyan-200 shadow-2xl flex items-center gap-3 animate-bounce">
          <Activity className="w-5 h-5 text-cyan-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-1">
          <span>Modo Coop (Cooperação Global)</span>
          <span aria-hidden="true">·</span>
          <span>Zero Conflitos</span>
          <span aria-hidden="true">·</span>
          <span>Fallback Automático</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Mecânica e Teste do Modo Coop
        </h1>
        <p className="mt-2 text-sm text-slate-300 leading-relaxed max-w-3xl">
          Quando o aplicativo de destino atribuído a um mouse, teclado ou mesa é fechado pelo usuário,
          o Koda Wintab detecta instantaneamente o encerramento do processo e transiciona os periféricos
          órfãos para o <strong>Modo Coop</strong>. Nenhum dispositivo trava; ambos operam juntos no sistema
          com <code>deviceId</code> independentes.
        </p>
      </div>

      {/* Interactive Trigger Sandbox */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Play className="w-4 h-4 text-cyan-400" />
              <span>Simulador de Fechamento de Aplicativos</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Clique para simular o fechamento de um aplicativo em execução e observe a transição automática.
            </p>
          </div>

          <button
            onClick={handleResetAll}
            className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg flex items-center gap-1.5 transition-colors self-start sm:self-auto"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restaurar Todos</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {TARGET_APPLICATIONS.slice(0, 3).map((app) => {
            const isClosed = closedApps.includes(app.name);
            const affectedDevices = hubDevices.filter((d) => d.targetApp === app.name);

            return (
              <div
                key={app.id}
                className={`p-4 rounded-xl border transition-all ${
                  isClosed
                    ? 'bg-rose-950/20 border-rose-500/40 text-rose-200'
                    : 'bg-slate-950 border-slate-800 text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-white">{app.name}</span>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                      isClosed
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    }`}
                  >
                    {isClosed ? 'FECHADO' : 'EM EXECUÇÃO'}
                  </span>
                </div>

                <div className="text-[11px] text-slate-400 mb-4">
                  {affectedDevices.length > 0 ? (
                    <span>
                      Vinculado a:{' '}
                      <strong className="text-white">
                        {affectedDevices.map((d) => d.name).join(', ')}
                      </strong>
                    </span>
                  ) : (
                    <span>Nenhum dispositivo atribuído</span>
                  )}
                </div>

                {isClosed ? (
                  <button
                    onClick={() => handleReopenApp(app.name)}
                    className="w-full py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded text-xs font-semibold transition-colors"
                  >
                    Reabrir Aplicativo
                  </button>
                ) : (
                  <button
                    onClick={() => handleSimulateCloseApp(app.name)}
                    className="w-full py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded text-xs font-semibold transition-colors"
                  >
                    Simular Fechamento do App
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Dual Pointer Simultaneous Coexistence Canvas */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 mb-8">
        <div className="mb-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-400" />
            <span>Demonstração de Coexistência Simultânea (Dual-Pointer)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Mova o cursor sobre a área abaixo. Em Modo Coop, o Android processa múltiplos <code>deviceId</code> (ex: 101 e 102)
            simultaneamente na mesma tela, sem conflito de estado de toque ou arraste.
          </p>
        </div>

        <div
          onMouseMove={handleTestMouseMove}
          className="relative w-full h-72 bg-slate-950 rounded-xl border border-slate-800 overflow-hidden cursor-none p-4"
        >
          {/* Grid lines */}
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#22d3ee_1px,transparent_1px)] [background-size:16px_16px]" />

          {/* Pointer 1 */}
          <div
            className="absolute transform -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-transform duration-75 flex items-center gap-1"
            style={{ left: `${pointer1Pos.x}px`, top: `${pointer1Pos.y}px` }}
          >
            <div className="w-4 h-4 rounded-full bg-cyan-400 border-2 border-white shadow-lg shadow-cyan-500/50" />
            <span className="text-[10px] font-mono font-bold bg-cyan-950/90 text-cyan-300 px-1.5 py-0.5 rounded border border-cyan-500/40 whitespace-nowrap">
              Mouse 1 (ID 101)
            </span>
          </div>

          {/* Pointer 2 */}
          <div
            className="absolute transform -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-transform duration-75 flex items-center gap-1"
            style={{ left: `${pointer2Pos.x}px`, top: `${pointer2Pos.y}px` }}
          >
            <div className="w-4 h-4 rounded-full bg-amber-400 border-2 border-white shadow-lg shadow-amber-500/50" />
            <span className="text-[10px] font-mono font-bold bg-amber-950/90 text-amber-300 px-1.5 py-0.5 rounded border border-amber-500/40 whitespace-nowrap">
              Mouse 2 (ID 102)
            </span>
          </div>

          <div className="absolute bottom-3 left-3 text-[11px] text-slate-500 font-mono">
            Interação simultânea ativa · Sem travamento mútuo · Roteamento por foco
          </div>
        </div>
      </div>

      {/* 3 Detection Pathways with Fallback */}
      <div className="border border-slate-800 rounded-2xl bg-slate-900/60 p-6">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <span>Os 3 Caminhos Técnicos de Detecção (com Fallback Automático)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <div className="text-xs font-bold text-cyan-400 font-mono mb-1">
              1. Koda Engine (Shell UID 2000)
            </div>
            <div className="text-xs font-semibold text-white mb-2">
              IProcessObserver / ActivityManager
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              O Koda Server registra um <code>IProcessObserver</code> privilegiado. Quando o PID do app de destino
              morre (<code>onProcessDied</code>) ou perde foco, o sinal é disparado em menos de 2ms.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <div className="text-xs font-bold text-indigo-400 font-mono mb-1">
              2. Fallback de Sistema
            </div>
            <div className="text-xs font-semibold text-white mb-2">
              UsageStatsManager Polling
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Caso a engine IPC sofra oscilação, o serviço entra em modo de observação de eventos
              <code>MOVE_TO_BACKGROUND</code> via estatísticas de uso em intervalo de 150ms.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <div className="text-xs font-bold text-emerald-400 font-mono mb-1">
              3. Apps Embutidos
            </div>
            <div className="text-xs font-semibold text-white mb-2">
              ActivityLifecycleCallbacks
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Para utilitários do próprio ecossistema Koda, callbacks de ciclo de vida nativo
              (<code>onStop</code> / <code>onDestroy</code>) informam o encerramento sem overhead.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
