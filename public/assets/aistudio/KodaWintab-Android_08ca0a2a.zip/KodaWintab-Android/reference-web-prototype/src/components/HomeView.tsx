import React from 'react';
import { ActiveView, TabletDevice, HubDevice, KodaEngineStatus } from '../types/koda';
import { 
  PenTool, 
  Layers, 
  ArrowRight, 
  ShieldCheck, 
  Monitor, 
  Cpu, 
  Gauge, 
  Code2, 
  FileCheck2, 
  Activity,
  Sparkles
} from 'lucide-react';

interface HomeViewProps {
  onNavigate: (view: ActiveView) => void;
  activeTablet: TabletDevice;
  hubDevices: HubDevice[];
  engineStatus: KodaEngineStatus;
  targetDisplay: string;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onNavigate,
  activeTablet,
  hubDevices,
  engineStatus,
  targetDisplay,
}) => {
  const coopCount = hubDevices.filter((d) => d.isCoop).length;

  return (
    <div className="max-w-6xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
      {/* Hero statement */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center gap-2 text-xs font-semibold text-cyan-400 mb-3">
          <span>Koda Wintab</span>
          <span aria-hidden="true">·</span>
          <span>Driver Global Unificado</span>
          <span aria-hidden="true">·</span>
          <span>Android 10+ (API 29–34)</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white" style={{ textWrap: 'balance' }}>
          Controle Total de Mesa Digitalizadora e Hub de Dispositivos
        </h1>
        <p className="mt-4 text-base text-slate-300 leading-relaxed">
          Precisão de nível PC para Wacom, Huion, Ugee e XP-Pen sem root. Pipeline de latência
          ultrabaixa (~8ms), injeção independente por janela e modo de cooperação global.
        </p>
      </div>

      {/* Two Main Hierarchical Buttons - Prominent as requested */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {/* 1. Botão Mesa */}
        <button
          onClick={() => onNavigate('tablet')}
          className="group relative p-8 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 hover:border-cyan-500/50 transition-all duration-300 text-left shadow-xl hover:shadow-cyan-950/20 flex flex-col justify-between min-h-[260px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl group-hover:bg-cyan-500/10 transition-colors" />

          <div>
            <div className="w-14 h-14 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-6 group-hover:scale-105 transition-transform">
              <PenTool className="w-7 h-7" />
            </div>
            <div className="text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1">
              Configuração &amp; Calibração
            </div>
            <h2 className="text-2xl font-bold text-white group-hover:text-cyan-200 transition-colors">
              Mesa Digitalizadora
            </h2>
            <p className="mt-2 text-sm text-slate-400 leading-relaxed">
              Driver Global (Ugee S640, Wacom, Huion, XP-Pen). Curva de pressão de 8192 níveis,
              rotação automática, área ativa proporcional e canvas de teste ao vivo.
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-cyan-400">
            <span>Abrir Painel da Mesa</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </div>
        </button>

        {/* 2. Botão Hub */}
        <button
          onClick={() => onNavigate('hub')}
          className="group relative p-8 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 hover:border-indigo-500/50 transition-all duration-300 text-left shadow-xl hover:shadow-indigo-950/20 flex flex-col justify-between min-h-[260px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl group-hover:bg-indigo-500/10 transition-colors" />

          <div>
            <div className="w-14 h-14 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-6 group-hover:scale-105 transition-transform">
              <Layers className="w-7 h-7" />
            </div>
            <div className="text-xs font-semibold text-indigo-400 uppercase tracking-wider mb-1">
              Múltiplos Dispositivos &amp; Janelas
            </div>
            <h2 className="text-2xl font-bold text-white group-hover:text-indigo-200 transition-colors">
              Hub de Dispositivos
            </h2>
            <p className="mt-2 text-sm text-slate-400 leading-relaxed">
              Gerencie 2 mouses, 2 teclados e 2 mesas simultâneos. Roteamento por janela,
              cursores personalizados e ativação transparente do Modo Coop.
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-indigo-400">
            <span>Abrir Gerenciador do Hub</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </div>
        </button>
      </div>

      {/* Quick Status Bar & Live System Overview */}
      <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Diagnóstico em Tempo Real do Subsistema
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Estado atual do pipeline de USB Host, Koda Engine e injeção de eventos
            </p>
          </div>
          <button
            onClick={() => onNavigate('vm_testing')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1.5 self-start sm:self-auto"
          >
            <span>Executar Validação na VM (API 29 vs 34)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Card 1 */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80">
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              <span>Koda Engine</span>
            </div>
            <div className="text-sm font-bold text-white truncate">
              {engineStatus.isActive ? 'UID 2000 (Ativa)' : 'Inativa (Requer ADB)'}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {engineStatus.isActive ? `PID ${engineStatus.pid} · IPC OK` : 'Aguardando comando'}
            </div>
          </div>

          {/* Card 2 */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80">
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <PenTool className="w-3.5 h-3.5 text-cyan-400" />
              <span>Mesa Detectada</span>
            </div>
            <div className="text-sm font-bold text-white truncate">
              {activeTablet.name.split('(')[0]}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              VID {activeTablet.vid} · {activeTablet.maxPressure} níveis
            </div>
          </div>

          {/* Card 3 */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80">
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <Monitor className="w-3.5 h-3.5 text-cyan-400" />
              <span>Saída de Display</span>
            </div>
            <div className="text-sm font-bold text-white">
              {targetDisplay === 'dex' ? 'Samsung DeX' : targetDisplay === 'pc_mode' ? 'Modo PC / Ready For' : 'Tela Interna'}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Mapeamento de área 1:1
            </div>
          </div>

          {/* Card 4 */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80">
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>Modo Coop</span>
            </div>
            <div className="text-sm font-bold text-white">
              {coopCount > 0 ? `${coopCount} Dispositivo(s) em Coop` : 'Standby (Roteados)'}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {coopCount > 0 ? 'Cooperação global ativa' : 'Monitorando fechamento de apps'}
            </div>
          </div>
        </div>
      </div>

      {/* Secondary quick navigation strips */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button
          onClick={() => onNavigate('coop')}
          className="p-4 rounded-xl bg-slate-900/40 hover:bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-colors text-left flex items-start justify-between"
        >
          <div>
            <div className="text-xs font-semibold text-slate-200">Simulador de Modo Coop</div>
            <div className="text-xs text-slate-400 mt-0.5">
              Simule o fechamento de apps e veja mouses/mesas operando juntos sem travar.
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-500 mt-1 shrink-0" />
        </button>

        <button
          onClick={() => onNavigate('architecture')}
          className="p-4 rounded-xl bg-slate-900/40 hover:bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-colors text-left flex items-start justify-between"
        >
          <div>
            <div className="text-xs font-semibold text-slate-200">Código Fonte Kotlin Nativo</div>
            <div className="text-xs text-slate-400 mt-0.5">
              Explore e copie os arquivos completos prontos para compilar no Android Studio.
            </div>
          </div>
          <Code2 className="w-4 h-4 text-slate-500 mt-1 shrink-0" />
        </button>

        <button
          onClick={() => onNavigate('activation')}
          className="p-4 rounded-xl bg-slate-900/40 hover:bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-colors text-left flex items-start justify-between"
        >
          <div>
            <div className="text-xs font-semibold text-slate-200">Comando ADB e Engine</div>
            <div className="text-xs text-slate-400 mt-0.5">
              Guia de ativação única do servidor e verificação de integridade do IPC.
            </div>
          </div>
          <Cpu className="w-4 h-4 text-slate-500 mt-1 shrink-0" />
        </button>
      </div>
    </div>
  );
};
