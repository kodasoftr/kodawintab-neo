import React, { useState } from 'react';
import { HubDevice, TargetApplication } from '../types/koda';
import { TARGET_APPLICATIONS } from '../data/tabletProfiles';
import { 
  Layers, 
  Mouse, 
  Keyboard, 
  PenTool, 
  MousePointer, 
  Check, 
  AlertCircle, 
  ArrowRight, 
  Sliders, 
  Crosshair,
  Dot,
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface HubViewProps {
  hubDevices: HubDevice[];
  setHubDevices: React.Dispatch<React.SetStateAction<HubDevice[]>>;
  onOpenCoopMode: () => void;
}

const AVAILABLE_CURSORS = [
  { id: 'default_arrow', name: 'Seta Padrão Android', type: 'system' },
  { id: 'crosshair', name: 'Mira Artística (Crosshair)', type: 'art' },
  { id: 'precision_dot', name: 'Ponto de Precisão (Sub-pixel Dot)', type: 'cad' },
  { id: 'pen_ring', name: 'Anel de Caneta Wacom/Stylus', type: 'pen' },
  { id: 'retro_amiga', name: 'Retro Cursor (.cur estilo Amiga)', type: 'custom' },
];

export const HubView: React.FC<HubViewProps> = ({
  hubDevices,
  setHubDevices,
  onOpenCoopMode,
}) => {
  const [selectedCursor, setSelectedCursor] = useState('crosshair');
  const [selectedCursorDevice, setSelectedCursorDevice] = useState<'mouse1' | 'mouse2'>('mouse1');
  const [hotspot, setHotspot] = useState<[number, number]>([8, 8]);

  const handleAssignApp = (deviceId: string, targetApp: string) => {
    setHubDevices((prev) =>
      prev.map((d) => (d.id === deviceId ? { ...d, targetApp, isCoop: false } : d))
    );
  };

  const handleToggleCoop = (deviceId: string) => {
    setHubDevices((prev) =>
      prev.map((d) => (d.id === deviceId ? { ...d, isCoop: !d.isCoop } : d))
    );
  };

  const handleApplyCursor = () => {
    setHubDevices((prev) =>
      prev.map((d) =>
        d.slot === selectedCursorDevice
          ? { ...d, cursorIcon: selectedCursor, cursorHotspot: hotspot }
          : d
      )
    );
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
      {/* Title & Introduction */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400 mb-1">
            <span>Janela Hub</span>
            <span aria-hidden="true">·</span>
            <span>Múltiplos Dispositivos Independentes</span>
            <span aria-hidden="true">·</span>
            <span>Roteamento por Janela Freeform</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Gerenciamento do Hub de Dispositivos
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            2 mouses + 2 teclados + 2 mesas operando simultaneamente com <code>deviceId</code> virtuais
            distintos, roteamento por aplicativo e Modo Coop.
          </p>
        </div>

        <button
          onClick={onOpenCoopMode}
          className="px-4 py-2.5 text-xs font-bold text-slate-950 bg-indigo-400 hover:bg-indigo-300 rounded-lg shadow-lg shadow-indigo-950/40 flex items-center gap-2 self-start md:self-auto transition-all"
        >
          <span>Abrir Simulador Modo Coop</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Grid of Devices (Cards) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {hubDevices.map((device) => {
          const isMouse = device.type === 'mouse';
          const isKeyboard = device.type === 'keyboard';
          const isTablet = device.type === 'tablet';

          return (
            <div
              key={device.id}
              className={`p-5 rounded-xl border transition-all ${
                device.isCoop
                  ? 'bg-amber-950/20 border-amber-500/40 text-amber-100'
                  : 'bg-slate-900/80 border-slate-800 text-slate-200'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold border ${
                      device.isCoop
                        ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                        : isTablet
                        ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400'
                        : isMouse
                        ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400'
                        : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                    }`}
                  >
                    {isMouse && <Mouse className="w-5 h-5" />}
                    {isKeyboard && <Keyboard className="w-5 h-5" />}
                    {isTablet && <PenTool className="w-5 h-5" />}
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-white">{device.name}</h3>
                    <div className="text-[11px] text-slate-400 truncate max-w-[160px]">
                      {device.hardwareName}
                    </div>
                  </div>
                </div>

                {/* Status Indicator */}
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase tracking-wider ${
                    device.isCoop
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  }`}
                >
                  {device.isCoop ? '🤝 Coop' : '🎯 Roteado'}
                </span>
              </div>

              {/* Hardware & Virtual Device ID */}
              <div className="space-y-2 py-3 border-y border-slate-800/80 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Virtual Device ID:</span>
                  <span className="font-mono text-cyan-400 font-semibold">{device.deviceId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Canal IPC:</span>
                  <span className="font-mono text-slate-300">InputChannel::{device.slot}</span>
                </div>
                {isMouse && device.cursorIcon && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Cursor Ativo:</span>
                    <span className="font-mono text-indigo-300 truncate max-w-[140px]">
                      {device.cursorIcon}
                    </span>
                  </div>
                )}
              </div>

              {/* Destination App Selector */}
              <div className="mt-4 space-y-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                    Aplicativo de Destino
                  </label>
                  <select
                    value={device.targetApp}
                    onChange={(e) => handleAssignApp(device.id, e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-indigo-400"
                  >
                    {TARGET_APPLICATIONS.map((app) => (
                      <option key={app.id} value={app.name}>
                        {app.name} ({app.packageName.split('.').slice(-2).join('.')})
                      </option>
                    ))}
                    <option value="Global (Sistema Todo)">Global (Sistema Todo)</option>
                  </select>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[11px] text-slate-400">
                    {device.isCoop ? 'Modo de cooperação forçado' : `Roteando para ${device.targetApp}`}
                  </span>
                  <button
                    onClick={() => handleToggleCoop(device.id)}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 font-medium"
                  >
                    {device.isCoop ? 'Voltar a Roteado' : 'Forçar Coop'}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Customizable Mouse Cursor Section (.cur / .png / PointerIcon) */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <MousePointer className="w-5 h-5 text-indigo-400" />
              <span>Personalização de Ícone do Cursor (PointerIcon)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Personalize o ponteiro físico para telas externas, Samsung DeX ou tablets que não possuem cursor nativo.
              Compatível com arquivos <code>.png</code> e <code>.cur</code> convertidos via <code>PointerIcon.create(bitmap, hotspotX, hotspotY)</code>.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Cursor Options */}
          <div className="lg:col-span-7 space-y-4">
            <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Escolher Estilo do Cursor
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {AVAILABLE_CURSORS.map((cursor) => (
                <button
                  key={cursor.id}
                  onClick={() => setSelectedCursor(cursor.id)}
                  className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-colors ${
                    selectedCursor === cursor.id
                      ? 'bg-indigo-500/10 border-indigo-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-indigo-300">
                    {cursor.id === 'crosshair' ? (
                      <Crosshair className="w-4 h-4" />
                    ) : cursor.id === 'precision_dot' ? (
                      <div className="w-2 h-2 rounded-full bg-cyan-400" />
                    ) : (
                      <MousePointer className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <div className="text-xs font-bold">{cursor.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      PointerIcon::{cursor.type}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Target mouse selector */}
            <div className="pt-3 border-t border-slate-800 flex items-center gap-4">
              <span className="text-xs text-slate-300 font-medium">Aplicar no:</span>
              <label className="flex items-center gap-1.5 text-xs text-slate-200 cursor-pointer">
                <input
                  type="radio"
                  name="target_mouse"
                  checked={selectedCursorDevice === 'mouse1'}
                  onChange={() => setSelectedCursorDevice('mouse1')}
                  className="accent-indigo-500"
                />
                <span>Mouse 1 (Logitech G Pro)</span>
              </label>
              <label className="flex items-center gap-1.5 text-xs text-slate-200 cursor-pointer">
                <input
                  type="radio"
                  name="target_mouse"
                  checked={selectedCursorDevice === 'mouse2'}
                  onChange={() => setSelectedCursorDevice('mouse2')}
                  className="accent-indigo-500"
                />
                <span>Mouse 2 (Razer Viper)</span>
              </label>
            </div>
          </div>

          {/* Hotspot & Preview */}
          <div className="lg:col-span-5 p-5 bg-slate-950 rounded-xl border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Ponto de Ancoragem (Hotspot)
              </div>
              <p className="text-xs text-slate-400 mb-4">
                Define a coordenada exata do clique dentro do bitmap do cursor.
              </p>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="text-xs font-mono text-slate-400">Hotspot X (px)</label>
                  <input
                    type="number"
                    value={hotspot[0]}
                    onChange={(e) => setHotspot([Number(e.target.value), hotspot[1]])}
                    className="w-full mt-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-mono text-slate-400">Hotspot Y (px)</label>
                  <input
                    type="number"
                    value={hotspot[1]}
                    onChange={(e) => setHotspot([hotspot[0], Number(e.target.value)])}
                    className="w-full mt-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white font-mono"
                  />
                </div>
              </div>

              {/* Visual preview box */}
              <div className="h-24 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-center relative">
                <div className="flex items-center gap-2 text-indigo-400 font-mono text-xs">
                  <Crosshair className="w-5 h-5 text-indigo-400" />
                  <span>Pré-visualização ({hotspot[0]}, {hotspot[1]})</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleApplyCursor}
              className="mt-4 w-full py-2 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold text-xs rounded-lg transition-colors"
            >
              Aplicar Cursor ao Dispositivo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
