import React from 'react';
import { ActiveView } from '../types/koda';
import { ShieldCheck, ShieldAlert, Moon, Sun } from 'lucide-react';

interface NavbarProps {
  currentView: ActiveView;
  onNavigate: (view: ActiveView) => void;
  isEngineActive: boolean;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  isEngineActive,
  isDarkMode,
  onToggleDarkMode,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark */}
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-md"
        >
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold text-sm tracking-wider">
            KW
          </div>
          <div className="flex flex-col">
            <span className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0">
              Koda Wintab
            </span>
            <span className="text-[11px] text-slate-400 whitespace-nowrap">
              Android 10+ (API 29–34)
            </span>
          </div>
        </button>

        {/* Zone 2: 4-5 clean single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300">
          <button
            onClick={() => onNavigate('home')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              currentView === 'home' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Início
          </button>
          <button
            onClick={() => onNavigate('tablet')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              currentView === 'tablet' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Mesa (Driver)
          </button>
          <button
            onClick={() => onNavigate('hub')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              currentView === 'hub' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Hub Dispositivos
          </button>
          <button
            onClick={() => onNavigate('coop')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              currentView === 'coop' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Modo Coop
          </button>
          <button
            onClick={() => onNavigate('architecture')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              currentView === 'architecture' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Código Kotlin
          </button>
          <button
            onClick={() => onNavigate('vm_testing')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              currentView === 'vm_testing' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            Validador VM
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onToggleDarkMode}
            title={isDarkMode ? 'Tema Claro' : 'Tema Escuro'}
            className="p-2 text-slate-400 hover:text-slate-200 border border-slate-800 rounded-lg hover:bg-slate-900 transition-colors"
            aria-label="Alternar tema"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            onClick={() => onNavigate('activation')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all whitespace-nowrap shrink-0 ${
              isEngineActive
                ? 'bg-emerald-950/50 text-emerald-300 border-emerald-500/40 hover:bg-emerald-900/60'
                : 'bg-amber-950/50 text-amber-300 border-amber-500/40 hover:bg-amber-900/60 animate-pulse'
            }`}
          >
            {isEngineActive ? (
              <>
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Engine Ativa (UID 2000)</span>
              </>
            ) : (
              <>
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                <span>Ativar Engine ADB</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
