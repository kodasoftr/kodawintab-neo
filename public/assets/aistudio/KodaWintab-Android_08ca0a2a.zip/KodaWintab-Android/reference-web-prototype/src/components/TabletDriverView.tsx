import React, { useState, useRef, useEffect } from 'react';
import { 
  TabletDevice, 
  TabletConfig, 
  OtdTab, 
  RawHidPacket,
  ActiveView 
} from '../types/koda';
import { SUPPORTED_TABLETS } from '../data/tabletProfiles';
import { 
  PenTool, 
  Sliders, 
  Maximize2, 
  RotateCw, 
  Compass, 
  Activity, 
  Monitor, 
  Layers, 
  Terminal, 
  Check, 
  Trash2, 
  RefreshCw,
  Gauge,
  Sparkles,
  MousePointer,
  HelpCircle
} from 'lucide-react';

interface TabletDriverViewProps {
  activeTablet: TabletDevice;
  setActiveTablet: (tablet: TabletDevice) => void;
  config: TabletConfig;
  setConfig: React.Dispatch<React.SetStateAction<TabletConfig>>;
  onOpenCoopMode: () => void;
}

export const TabletDriverView: React.FC<TabletDriverViewProps> = ({
  activeTablet,
  setActiveTablet,
  config,
  setConfig,
  onOpenCoopMode,
}) => {
  const [activeTab, setActiveTab] = useState<OtdTab>('tablet');
  const [activeTabletSlot, setActiveTabletSlot] = useState<'mesa1' | 'mesa2' | 'global'>('global');
  
  // Real-time test tools state
  const [currentPressure, setCurrentPressure] = useState<number>(0);
  const [curvedPressure, setCurvedPressure] = useState<number>(0);
  const [pollingRate, setPollingRate] = useState<number>(500); // Hz
  const [latencyMs, setLatencyMs] = useState<number>(8.4); // ms
  const [isDrawing, setIsDrawing] = useState(false);
  const [calibrationStep, setCalibrationStep] = useState<number | null>(null);

  // Raw HID stream simulation
  const [rawPackets, setRawPackets] = useState<RawHidPacket[]>([
    {
      timestamp: Date.now() - 40,
      hex: '02 01 4B 12 7F 08 C4 1F 00 00',
      reportId: 2,
      status: 'Tip Down (Drawing)',
      x: 18450,
      y: 9230,
      pressure: 7420,
      tiltX: 12,
      tiltY: -8,
    },
    {
      timestamp: Date.now() - 20,
      hex: '02 01 4E 12 85 08 E2 1F 00 00',
      reportId: 2,
      status: 'Tip Down (Drawing)',
      x: 18478,
      y: 9245,
      pressure: 7850,
      tiltX: 13,
      tiltY: -7,
    },
  ]);

  // Canvas drawing ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Calculate curved pressure based on curve type
  const calculatePressureCurve = (raw: number, max: number): number => {
    const normalized = Math.min(1, Math.max(0, (raw - config.minPressureThreshold) / (config.maxPressureThreshold - config.minPressureThreshold)));
    if (config.pressureCurve === 'linear') return normalized;
    if (config.pressureCurve === 'soft') return Math.pow(normalized, 0.65);
    if (config.pressureCurve === 'firm') return Math.pow(normalized, 1.6);
    if (config.pressureCurve === 'aggressive') return Math.pow(normalized, 2.2);
    if (config.pressureCurve === 'scurve') {
      return 1 / (1 + Math.exp(-10 * (normalized - 0.5)));
    }
    return normalized;
  };

  // Canvas drawing handler with PointerEvent support (real pen pressure or mouse fallback)
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setIsDrawing(true);
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Use actual stylus pressure if available, otherwise simulated
    const p = e.pressure > 0 ? e.pressure : 0.6;
    const rawP = Math.round(p * activeTablet.maxPressure);
    setCurrentPressure(rawP);
    const cp = calculatePressureCurve(rawP, activeTablet.maxPressure);
    setCurvedPressure(cp);

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }

    // Add to raw packet stream
    appendRawPacket(rawP, x, y, 'Tip Down');
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const p = e.pressure > 0 ? e.pressure : 0.65;
    const rawP = Math.round(p * activeTablet.maxPressure);
    setCurrentPressure(rawP);
    const cp = calculatePressureCurve(rawP, activeTablet.maxPressure);
    setCurvedPressure(cp);

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.lineWidth = Math.max(1, cp * 18);
      ctx.strokeStyle = '#22d3ee'; // cyan-400
      ctx.lineTo(x, y);
      ctx.stroke();
    }

    appendRawPacket(rawP, x, y, 'Tip Down');
  };

  const handlePointerUp = () => {
    setIsDrawing(false);
    setCurrentPressure(0);
    setCurvedPressure(0);
  };

  const appendRawPacket = (pressure: number, x: number, y: number, status: string) => {
    const hexX = Math.round(x * 50).toString(16).padStart(4, '0').toUpperCase();
    const hexY = Math.round(y * 50).toString(16).padStart(4, '0').toUpperCase();
    const hexP = Math.round(pressure).toString(16).padStart(4, '0').toUpperCase();
    
    const newPacket: RawHidPacket = {
      timestamp: Date.now(),
      hex: `02 01 ${hexX.slice(2,4)} ${hexX.slice(0,2)} ${hexY.slice(2,4)} ${hexY.slice(0,2)} ${hexP.slice(2,4)} ${hexP.slice(0,2)} 00 00`,
      reportId: 2,
      status: status,
      x: Math.round(x * 50),
      y: Math.round(y * 50),
      pressure: pressure,
      tiltX: 12,
      tiltY: -6,
    };

    setRawPackets((prev) => [newPacket, ...prev.slice(0, 7)]);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  // Calibration sequence
  const startCalibration = () => {
    setCalibrationStep(1);
  };

  const handleCalibrationClick = (cornerIndex: number) => {
    if (calibrationStep === 4) {
      setCalibrationStep(null);
    } else {
      setCalibrationStep((prev) => (prev ? prev + 1 : null));
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
      {/* Top Banner: Global Driver Auto-Detection */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
            <PenTool className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">
                Driver Global Unificado
              </span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-emerald-400 font-medium">Reconhecimento Automático</span>
            </div>
            <h1 className="text-lg font-bold text-white">
              {activeTablet.name}
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Quick Tablet Selector */}
          <select
            value={activeTablet.id}
            onChange={(e) => {
              const selected = SUPPORTED_TABLETS.find((t) => t.id === e.target.value);
              if (selected) setActiveTablet(selected);
            }}
            className="px-3 py-1.5 text-xs bg-slate-950 border border-slate-700 rounded-lg text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
          >
            {SUPPORTED_TABLETS.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.vid}:{t.pid})
              </option>
            ))}
          </select>

          {/* Slot selector */}
          <div className="flex items-center p-0.5 bg-slate-950 border border-slate-800 rounded-lg text-xs font-medium">
            <button
              onClick={() => setActiveTabletSlot('global')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                activeTabletSlot === 'global' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Modo Global (1 Mesa)
            </button>
            <button
              onClick={() => setActiveTabletSlot('mesa1')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                activeTabletSlot === 'mesa1' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Mesa 1
            </button>
            <button
              onClick={() => setActiveTabletSlot('mesa2')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                activeTabletSlot === 'mesa2' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Mesa 2
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Tabs & Configuration + Live Test Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: OpenTabletDriver Faithful Tabs (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Tab Navigation */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl overflow-x-auto">
            <button
              onClick={() => setActiveTab('tablet')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'tablet'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tablet (Área &amp; Rotação)
            </button>
            <button
              onClick={() => setActiveTab('pen')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'pen'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Pen (Pressão &amp; Curva)
            </button>
            <button
              onClick={() => setActiveTab('bindings')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'bindings'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Bindings (Express Keys)
            </button>
            <button
              onClick={() => setActiveTab('filters')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'filters'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Filters (Anti-Jitter)
            </button>
            <button
              onClick={() => setActiveTab('output')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'output'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Output (DeX &amp; Telas)
            </button>
          </div>

          {/* TAB 1: TABLET (Area, Mapping, Rotation, Invert) */}
          {activeTab === 'tablet' && (
            <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Mapeamento da Área Ativa
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Área física detectada: {activeTablet.physicalWidthMm} × {activeTablet.physicalHeightMm} mm
                  (Resolução nativa: {activeTablet.maxRawX} × {activeTablet.maxRawY} sub-pixels)
                </p>
              </div>

              {/* Visual Active Area Preview */}
              <div className="relative w-full h-48 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-center overflow-hidden">
                <div
                  className="relative border-2 border-cyan-400 bg-cyan-500/10 rounded transition-all duration-200 flex items-center justify-center"
                  style={{
                    width: `${(config.areaWidthMm / activeTablet.physicalWidthMm) * 80}%`,
                    height: `${(config.areaHeightMm / activeTablet.physicalHeightMm) * 75}%`,
                    transform: `rotate(${config.rotation}deg) scaleX(${config.invertX ? -1 : 1}) scaleY(${config.invertY ? -1 : 1})`,
                  }}
                >
                  <div className="text-[11px] font-mono font-bold text-cyan-300">
                    {config.areaWidthMm} × {config.areaHeightMm} mm
                  </div>
                  <div className="absolute top-1 left-1.5 text-[9px] font-mono text-cyan-400">
                    (0,0)
                  </div>
                </div>
                <div className="absolute bottom-2 right-3 text-[10px] text-slate-500 font-mono">
                  Superfície Total da Mesa
                </div>
              </div>

              {/* Sliders */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-slate-300 flex justify-between">
                    <span>Largura da Área (mm)</span>
                    <span className="font-mono text-cyan-400">{config.areaWidthMm} mm</span>
                  </label>
                  <input
                    type="range"
                    min="20"
                    max={activeTablet.physicalWidthMm}
                    value={config.areaWidthMm}
                    onChange={(e) =>
                      setConfig((prev) => ({
                        ...prev,
                        areaWidthMm: Number(e.target.value),
                        areaHeightMm: prev.lockAspectRatio
                          ? Math.round(Number(e.target.value) * (activeTablet.physicalHeightMm / activeTablet.physicalWidthMm))
                          : prev.areaHeightMm,
                      }))
                    }
                    className="w-full mt-2 accent-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300 flex justify-between">
                    <span>Altura da Área (mm)</span>
                    <span className="font-mono text-cyan-400">{config.areaHeightMm} mm</span>
                  </label>
                  <input
                    type="range"
                    min="20"
                    max={activeTablet.physicalHeightMm}
                    value={config.areaHeightMm}
                    onChange={(e) =>
                      setConfig((prev) => ({
                        ...prev,
                        areaHeightMm: Number(e.target.value),
                      }))
                    }
                    className="w-full mt-2 accent-cyan-400"
                  />
                </div>
              </div>

              {/* Rotation & Axis Inversion */}
              <div className="pt-4 border-t border-slate-800">
                <div className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                  Rotação &amp; Orientação
                </div>

                <div className="flex flex-wrap items-center gap-2 mb-4">
                  {([0, 90, 180, 270] as const).map((deg) => (
                    <button
                      key={deg}
                      onClick={() => setConfig((prev) => ({ ...prev, rotation: deg }))}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                        config.rotation === deg
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {deg}° {deg === 0 ? '(Padrão)' : deg === 180 ? '(Canhoto)' : ''}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <label className="flex items-center gap-2.5 p-3 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.autoRotateWithScreen}
                      onChange={(e) => setConfig((prev) => ({ ...prev, autoRotateWithScreen: e.target.checked }))}
                      className="rounded accent-cyan-400"
                    />
                    <span className="text-xs text-slate-300 font-medium">
                      Girar com a Tela (Auto)
                    </span>
                  </label>

                  <label className="flex items-center gap-2.5 p-3 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.invertX}
                      onChange={(e) => setConfig((prev) => ({ ...prev, invertX: e.target.checked }))}
                      className="rounded accent-cyan-400"
                    />
                    <span className="text-xs text-slate-300 font-medium">
                      Inverter Eixo X (↔️)
                    </span>
                  </label>

                  <label className="flex items-center gap-2.5 p-3 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.invertY}
                      onChange={(e) => setConfig((prev) => ({ ...prev, invertY: e.target.checked }))}
                      className="rounded accent-cyan-400"
                    />
                    <span className="text-xs text-slate-300 font-medium">
                      Inverter Eixo Y (↕️)
                    </span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PEN (Pressure curve & thresholds) */}
          {activeTab === 'pen' && (
            <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Curva de Pressão Nível PC ({activeTablet.maxPressure} Níveis)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Mapeamento direto sobre o valor nativo reportado pelo sensor USB, sem interpolação destrutiva.
                </p>
              </div>

              {/* Curve Selection */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {(['linear', 'soft', 'firm', 'aggressive', 'scurve'] as const).map((curve) => (
                  <button
                    key={curve}
                    onClick={() => setConfig((prev) => ({ ...prev, pressureCurve: curve }))}
                    className={`px-3 py-2 text-xs font-semibold rounded-lg border capitalize transition-colors ${
                      config.pressureCurve === curve
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {curve === 'scurve' ? 'Curva S' : curve}
                  </button>
                ))}
              </div>

              {/* Curve SVG Diagram */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col items-center">
                <svg className="w-full h-40 max-w-sm" viewBox="0 0 200 100">
                  {/* Grid lines */}
                  <line x1="10" y1="90" x2="190" y2="90" stroke="#334155" strokeWidth="1" />
                  <line x1="10" y1="10" x2="10" y2="90" stroke="#334155" strokeWidth="1" />
                  <line x1="10" y1="50" x2="190" y2="50" stroke="#1e293b" strokeDasharray="2" strokeWidth="1" />
                  <line x1="100" y1="10" x2="100" y2="90" stroke="#1e293b" strokeDasharray="2" strokeWidth="1" />

                  {/* Curve path */}
                  {config.pressureCurve === 'linear' && (
                    <line x1="10" y1="90" x2="190" y2="10" stroke="#22d3ee" strokeWidth="3" />
                  )}
                  {config.pressureCurve === 'soft' && (
                    <path d="M 10 90 Q 60 20 190 10" fill="none" stroke="#22d3ee" strokeWidth="3" />
                  )}
                  {config.pressureCurve === 'firm' && (
                    <path d="M 10 90 Q 140 80 190 10" fill="none" stroke="#22d3ee" strokeWidth="3" />
                  )}
                  {config.pressureCurve === 'aggressive' && (
                    <path d="M 10 90 Q 170 90 190 10" fill="none" stroke="#22d3ee" strokeWidth="3" />
                  )}
                  {config.pressureCurve === 'scurve' && (
                    <path d="M 10 90 C 70 90 130 10 190 10" fill="none" stroke="#22d3ee" strokeWidth="3" />
                  )}
                </svg>

                <div className="flex justify-between w-full max-w-sm text-[10px] font-mono text-slate-500 mt-2 px-2">
                  <span>Toque Leve (0)</span>
                  <span>Pressão Máxima ({activeTablet.maxPressure})</span>
                </div>
              </div>

              {/* Thresholds */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-slate-300 flex justify-between">
                    <span>Pressão Mínima de Ativação</span>
                    <span className="font-mono text-cyan-400">{config.minPressureThreshold}</span>
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="1000"
                    value={config.minPressureThreshold}
                    onChange={(e) => setConfig((prev) => ({ ...prev, minPressureThreshold: Number(e.target.value) }))}
                    className="w-full mt-2 accent-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300 flex justify-between">
                    <span>Limite Máximo (Clamp)</span>
                    <span className="font-mono text-cyan-400">{config.maxPressureThreshold}</span>
                  </label>
                  <input
                    type="range"
                    min="4000"
                    max={activeTablet.maxPressure}
                    value={config.maxPressureThreshold}
                    onChange={(e) => setConfig((prev) => ({ ...prev, maxPressureThreshold: Number(e.target.value) }))}
                    className="w-full mt-2 accent-cyan-400"
                  />
                </div>
              </div>

              {/* Pen Buttons */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <div className="text-xs font-bold text-white uppercase tracking-wider">
                  Botões da Caneta (Stylus)
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <div className="text-xs text-slate-400 mb-1">Botão Inferior (Button 1)</div>
                    <select
                      value={config.penButton1Action}
                      onChange={(e) => setConfig((prev) => ({ ...prev, penButton1Action: e.target.value }))}
                      className="w-full text-xs bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none"
                    >
                      <option value="Borracha (Eraser Toggle)">Borracha (Eraser Toggle)</option>
                      <option value="Botão Direito (Right Click)">Botão Direito (Right Click)</option>
                      <option value="Desfazer (Undo)">Desfazer (Undo)</option>
                      <option value="Conta-gotas (Eyedropper)">Conta-gotas (Eyedropper)</option>
                    </select>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <div className="text-xs text-slate-400 mb-1">Botão Superior (Button 2)</div>
                    <select
                      value={config.penButton2Action}
                      onChange={(e) => setConfig((prev) => ({ ...prev, penButton2Action: e.target.value }))}
                      className="w-full text-xs bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white focus:outline-none"
                    >
                      <option value="Mover / Panorâmica (Pan Hand)">Mover / Panorâmica (Pan Hand)</option>
                      <option value="Botão do Meio (Middle Click)">Botão do Meio (Middle Click)</option>
                      <option value="Zoom Interativo">Zoom Interativo</option>
                      <option value="Alternar Camada">Alternar Camada</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: BINDINGS (Express keys) */}
          {activeTab === 'bindings' && (
            <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Mapeamento de Teclas Expressas (Express Keys)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Atalhos físicos mapeados para injeção via InputManager no aplicativo em foco.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {Object.entries(config.expressKeys).map(([key, shortcut]) => (
                  <div key={key} className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded bg-slate-800 font-mono text-xs font-bold text-cyan-400 flex items-center justify-center">
                        {key}
                      </span>
                      <span className="text-xs font-medium text-slate-200">{shortcut}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">Injetado</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: FILTERS (Anti-jitter, bezier, tilt) */}
          {activeTab === 'filters' && (
            <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Filtros de Entrada (Opcionais · Padrão Raw)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Filtros computacionais executados na thread de display prioritária antes da injeção.
                </p>
              </div>

              <div className="space-y-4">
                <label className="flex items-start gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.antiJitterEnabled}
                    onChange={(e) => setConfig((prev) => ({ ...prev, antiJitterEnabled: e.target.checked }))}
                    className="mt-1 rounded accent-cyan-400"
                  />
                  <div>
                    <div className="text-xs font-bold text-white">Filtro Anti-Jitter</div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Elimina micro-tremores em linhas lentas preservando a velocidade em traços rápidos.
                    </div>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.bezierSmoothing}
                    onChange={(e) => setConfig((prev) => ({ ...prev, bezierSmoothing: e.target.checked }))}
                    className="mt-1 rounded accent-cyan-400"
                  />
                  <div>
                    <div className="text-xs font-bold text-white">Suavização Bezier Sub-Pixel</div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Interpola coordenadas flutuantes sem arredondamento prematuro.
                    </div>
                  </div>
                </label>

                <label className="flex items-start gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.tiltCompensation}
                    onChange={(e) => setConfig((prev) => ({ ...prev, tiltCompensation: e.target.checked }))}
                    className="mt-1 rounded accent-cyan-400"
                  />
                  <div>
                    <div className="text-xs font-bold text-white">Compensação de Inclinação (Tilt ±60°)</div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Compensa o ponto de contato da ponta conforme a caneta se inclina.
                    </div>
                  </div>
                </label>
              </div>
            </div>
          )}

          {/* TAB 5: OUTPUT (Target Screen & DisplayManager) */}
          {activeTab === 'output' && (
            <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800 space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Destino da Saída &amp; DisplayManager
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Selecione para qual tela os eventos virtuais com deviceId único serão injetados.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => setConfig((prev) => ({ ...prev, targetDisplay: 'internal' }))}
                  className={`p-4 rounded-xl border text-left transition-colors ${
                    config.targetDisplay === 'internal'
                      ? 'bg-cyan-500/10 border-cyan-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-bold">Tela Interna (Display 0)</div>
                  <div className="text-xs text-slate-400 mt-1 font-mono">2560 × 1600 · 120Hz</div>
                </button>

                <button
                  onClick={() => setConfig((prev) => ({ ...prev, targetDisplay: 'dex' }))}
                  className={`p-4 rounded-xl border text-left transition-colors ${
                    config.targetDisplay === 'dex'
                      ? 'bg-cyan-500/10 border-cyan-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-bold">Samsung DeX (Desktop)</div>
                  <div className="text-xs text-slate-400 mt-1 font-mono">1920 × 1080 · 60Hz</div>
                </button>

                <button
                  onClick={() => setConfig((prev) => ({ ...prev, targetDisplay: 'pc_mode' }))}
                  className={`p-4 rounded-xl border text-left transition-colors ${
                    config.targetDisplay === 'pc_mode'
                      ? 'bg-cyan-500/10 border-cyan-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-bold">Modo PC / Motorola Ready For</div>
                  <div className="text-xs text-slate-400 mt-1 font-mono">Display Externo Primário</div>
                </button>

                <button
                  onClick={() => setConfig((prev) => ({ ...prev, targetDisplay: 'external' }))}
                  className={`p-4 rounded-xl border text-left transition-colors ${
                    config.targetDisplay === 'external'
                      ? 'bg-cyan-500/10 border-cyan-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-bold">Espelhamento / Multi-Display</div>
                  <div className="text-xs text-slate-400 mt-1 font-mono">Mapeamento Dinâmico</div>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Live Testing Suite (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Live Drawing Canvas Card */}
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Canvas de Traço em Tempo Real
                </h3>
                <p className="text-[11px] text-slate-400">
                  Teste de sensibilidade à pressão (suporta caneta real ou cursor)
                </p>
              </div>
              <button
                onClick={clearCanvas}
                className="p-1.5 text-slate-400 hover:text-white rounded border border-slate-800 hover:bg-slate-800 transition-colors"
                title="Limpar Canvas"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Canvas */}
            <div className="relative w-full h-64 bg-slate-950 rounded-lg border border-slate-800 overflow-hidden cursor-crosshair">
              <canvas
                ref={canvasRef}
                width={480}
                height={256}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerLeave={handlePointerUp}
                className="w-full h-full touch-none"
              />

              {/* Calibration Guide overlay */}
              {calibrationStep !== null && (
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-4">
                  <div className="text-xs font-bold text-cyan-300 mb-2">
                    Assistente de Calibração Guiada (Ponto {calibrationStep}/4)
                  </div>
                  <p className="text-[11px] text-slate-300 text-center mb-4">
                    Toque com a ponta da caneta no alvo que pisca no canto indicado.
                  </p>
                  <button
                    onClick={() => handleCalibrationClick(calibrationStep)}
                    className="px-4 py-2 bg-cyan-400 text-slate-950 font-bold text-xs rounded-lg shadow-md animate-pulse"
                  >
                    Confirmar Ponto {calibrationStep}
                  </button>
                </div>
              )}
            </div>

            {/* Pressure gauge bar */}
            <div className="mt-4 pt-3 border-t border-slate-800">
              <div className="flex justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-400">Pressão Nativa: <strong className="text-white">{currentPressure}</strong> / {activeTablet.maxPressure}</span>
                <span className="text-cyan-400 font-bold">{Math.round(curvedPressure * 100)}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 transition-all duration-75"
                  style={{ width: `${curvedPressure * 100}%` }}
                />
              </div>
            </div>

            {/* Quick Actions under canvas */}
            <div className="mt-4 flex items-center justify-between text-xs pt-3 border-t border-slate-800">
              <button
                onClick={startCalibration}
                className="text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
              >
                <Compass className="w-3.5 h-3.5" />
                <span>Calibração 4 Cantos</span>
              </button>

              <button
                onClick={onOpenCoopMode}
                className="text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Testar Modo Coop</span>
              </button>
            </div>
          </div>

          {/* Latency & Polling Meter */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs font-bold text-white uppercase tracking-wider">
                Medidor de Latência &amp; Polling Rate
              </div>
              <span className="text-[11px] font-mono text-emerald-400 font-semibold">
                THREAD URGENTE
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="text-[11px] text-slate-400">Latência do Traço</div>
                <div className="text-xl font-bold font-mono text-white mt-1">
                  {latencyMs} <span className="text-xs font-normal text-slate-400">ms</span>
                </div>
                <div className="text-[10px] text-emerald-400 mt-1">
                  ✓ Alvo &lt; 16ms (1 frame)
                </div>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="text-[11px] text-slate-400">Taxa USB Polling</div>
                <div className="text-xl font-bold font-mono text-white mt-1">
                  {pollingRate} <span className="text-xs font-normal text-slate-400">Hz</span>
                </div>
                <div className="text-[10px] text-cyan-400 mt-1">
                  Zero pacotes descartados
                </div>
              </div>
            </div>
          </div>

          {/* Raw HID Hex Monitor */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <span>Monitor Hex Dump (HID Raw)</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400">
                VID:{activeTablet.vid} PID:{activeTablet.pid}
              </span>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 space-y-1 max-h-36 overflow-y-auto">
              {rawPackets.map((pkt, idx) => (
                <div key={idx} className="flex justify-between gap-2 border-b border-slate-900/60 pb-0.5">
                  <span className="text-cyan-400">{pkt.hex}</span>
                  <span className="text-slate-400 truncate">P:{pkt.pressure}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
