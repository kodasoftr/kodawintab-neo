export interface KotlinSourceFile {
  id: string;
  filename: string;
  path: string;
  description: string;
  language: 'kotlin' | 'xml' | 'bash';
  code: string;
}

export const KOTLIN_ARCHITECTURE_FILES: KotlinSourceFile[] = [
  {
    id: 'koda_server',
    filename: 'KodaServer.kt',
    path: 'com/koda/wintab/engine/KodaServer.kt',
    description: 'Processo servidor privilegiado com UID shell (2000), Binder/AIDL e injeção de eventos',
    language: 'kotlin',
    code: `package com.koda.wintab.engine

import android.hardware.input.IInputManager
import android.os.Binder
import android.os.IBinder
import android.os.ServiceManager
import android.view.InputEvent
import android.view.MotionEvent
import android.util.Log
import java.io.FileDescriptor

/**
 * KodaServer - Engine de privilégio Shell (UID 2000).
 * Executa independentemente de root via bootstrap único pelo ADB.
 * Habilita INJECT_EVENTS, controle de janelas IWindowManager e VBUS.
 */
class KodaServer : IKodaEngine.Stub() {

    private val inputManager: IInputManager by lazy {
        val binder = ServiceManager.getService("input")
            ?: throw IllegalStateException("InputManager service not found")
        IInputManager.Stub.asInterface(binder)
    }

    private val sessionToken: String = generateSecureToken()

    override fun verifyToken(token: String): Boolean {
        return this.sessionToken == token
    }

    override fun injectGlobalEvent(event: InputEvent, mode: Int): Boolean {
        return try {
            // mode = 2 (INJECT_INPUT_EVENT_MODE_ASYNC) para máxima taxa de quadros
            inputManager.injectInputEvent(event, mode)
        } catch (e: Exception) {
            Log.e(TAG, "Falha ao injetar evento global de entrada", e)
            false
        }
    }

    override fun setVbusState(enabled: Boolean): Boolean {
        // Controle de alimentação OTG VBUS para economizar energia no Android 10+
        return try {
            val cmd = if (enabled) "echo 1 > /sys/class/power_supply/usb/otg_vbus" 
                      else "echo 0 > /sys/class/power_supply/usb/otg_vbus"
            Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd)).waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    companion object {
        private const val TAG = "KodaServer"

        @JvmStatic
        fun main(args: Array<String>) {
            Log.i(TAG, "Iniciando KodaServer daemon (UID: \${android.os.Process.myUid()})...")
            val server = KodaServer()
            
            // Publica o serviço no ServiceManager interno ou socket de domínio local
            ServiceManager.addService("koda_engine_service", server)
            
            // Mantém o Looper do processo vivo para atender chamadas Binder
            android.os.Looper.prepareMainLooper()
            android.os.Looper.loop()
        }

        private fun generateSecureToken(): String {
            return java.util.UUID.randomUUID().toString()
        }
    }
}`
  },
  {
    id: 'usb_service',
    filename: 'UsbDriverService.kt',
    path: 'com/koda/wintab/service/UsbDriverService.kt',
    description: 'Foreground Service (API 29+) com tipos declarados e gerenciamento do ciclo de vida USB',
    language: 'kotlin',
    code: `package com.koda.wintab.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.koda.wintab.driver.GlobalTabletDriver

/**
 * UsbDriverService - Gerencia conexão USB Host com prioridade em foreground.
 * Compatível com Android 10 (API 29) até Android 14+ (API 34).
 */
class UsbDriverService : Service() {

    private lateinit var usbManager: UsbManager
    private var globalDriver: GlobalTabletDriver? = null

    override fun onCreate() {
        super.onCreate()
        usbManager = getSystemService(USB_SERVICE) as UsbManager
        startInForeground()
    }

    private fun startInForeground() {
        val channelId = "koda_wintab_driver"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Koda Wintab Driver Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Koda Wintab Ativo")
            .setContentText("Driver Global operando com latência ultrabaixa")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .build()

        // Android 10 (API 29) e Android 14 (API 34) exigem tipo connectedDevice
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID, 
                notification, 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    fun attachUsbTablet(device: UsbDevice) {
        val connection = usbManager.openDevice(device) ?: return
        globalDriver = GlobalTabletDriver(this, device, connection).apply {
            startReading()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        globalDriver?.stopReading()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 2026
    }
}`
  },
  {
    id: 'ugee_parser',
    filename: 'UgeeS640Parser.kt',
    path: 'com/koda/wintab/driver/parser/UgeeS640Parser.kt',
    description: 'Parser dedicado de alta precisão para Ugee S640 com inicialização controlTransfer',
    language: 'kotlin',
    code: `package com.koda.wintab.driver.parser

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbInterface
import android.util.Log

/**
 * UgeeS640Parser - Parser dedicado de zero-alocação para Ugee S640.
 * Executa handshake de inicialização via controlTransfer e decodifica até 8192 níveis de pressão.
 */
class UgeeS640Parser : TabletParser {

    override val vendorId: Int = 0x28BD
    override val productId: Int = 0x0914

    override fun initializeDevice(connection: UsbDeviceConnection, usbInterface: UsbInterface): Boolean {
        // Forçar claim da interface USB
        val claimed = connection.claimInterface(usbInterface, true)
        if (!claimed) {
            Log.e("UgeeS640", "Falha ao executar claimInterface(force=true)")
            return false
        }

        // Comando de ativação HID proprietário da Ugee/XP-Pen
        val magicBuffer = byteArrayOf(0x02, 0xB0.toByte(), 0x04, 0x00, 0x00, 0x00, 0x00, 0x00)
        val result = connection.controlTransfer(
            0x21, // REQUEST_TYPE_CLASS | RECIPIENT_INTERFACE
            0x09, // SET_REPORT
            0x0302, // Feature Report 0x02
            usbInterface.id,
            magicBuffer,
            magicBuffer.size,
            1000
        )

        Log.i("UgeeS640", "Handshake de inicialização Ugee enviado: result=\$result")
        return result >= 0
    }

    /**
     * Parsing sem alocação no hot path: reutiliza a instância de TabletState pré-alocada.
     */
    override fun parseReport(buffer: ByteArray, length: Int, outState: TabletState): Boolean {
        if (length < 8) return false
        val reportId = buffer[0].toInt() and 0xFF

        // Report ID 0x02: Pacote de caneta (coordenadas, pressão, botões)
        if (reportId == 0x02) {
            val statusByte = buffer[1].toInt() and 0xFF
            outState.isTipDown = (statusByte and 0x01) != 0
            outState.isButton1 = (statusByte and 0x02) != 0
            outState.isButton2 = (statusByte and 0x04) != 0
            outState.isHover = (statusByte and 0x20) != 0

            // 16-bit little endian para coordenadas X e Y
            outState.rawX = (buffer[2].toInt() and 0xFF) or ((buffer[3].toInt() and 0xFF) shl 8)
            outState.rawY = (buffer[4].toInt() and 0xFF) or ((buffer[5].toInt() and 0xFF) shl 8)

            // 8192 níveis de pressão (13 bits)
            outState.rawPressure = (buffer[6].toInt() and 0xFF) or ((buffer[7].toInt() and 0x1F) shl 8)

            if (length >= 10) {
                outState.tiltX = buffer[8].toInt() // -60..+60 graus
                outState.tiltY = buffer[9].toInt()
            }
            return true
        }

        // Report ID 0x03: Express Keys K1..K8
        if (reportId == 0x03) {
            outState.keyMask = (buffer[1].toInt() and 0xFF) or ((buffer[2].toInt() and 0xFF) shl 8)
            return true
        }

        return false
    }
}`
  },
  {
    id: 'coordinate_transformer',
    filename: 'CoordinateTransformer.kt',
    path: 'com/koda/wintab/pipeline/CoordinateTransformer.kt',
    description: 'Matriz de transformação pré-calculada para rotação (0/90/180/270), inversão X/Y e DPI nativo',
    language: 'kotlin',
    code: `package com.koda.wintab.pipeline

import android.graphics.Matrix
import android.graphics.RectF

/**
 * CoordinateTransformer - Pipeline sub-pixel sem alocação.
 * Aplica rotação manual ou automática sincronizada com OrientationEventListener.
 */
class CoordinateTransformer(
    private var tabletWidthMm: Float,
    private var tabletHeightMm: Float,
    private var screenWidthPx: Float,
    private var screenHeightPx: Float
) {
    private val transformMatrix = Matrix()
    private val pointsBuffer = FloatArray(2)

    var rotationDegrees: Int = 0
        set(value) {
            field = value
            recalculateMatrix()
        }

    var invertX: Boolean = false
        set(value) {
            field = value
            recalculateMatrix()
        }

    var invertY: Boolean = false
        set(value) {
            field = value
            recalculateMatrix()
        }

    init {
        recalculateMatrix()
    }

    private fun recalculateMatrix() {
        transformMatrix.reset()

        // 1. Normalização 0.0 -> 1.0 da área ativa
        val scaleX = screenWidthPx / tabletWidthMm
        val scaleY = screenHeightPx / tabletHeightMm
        transformMatrix.postScale(scaleX, scaleY)

        // 2. Rotação (0, 90, 180, 270) em torno do centro
        if (rotationDegrees != 0) {
            transformMatrix.postRotate(
                rotationDegrees.toFloat(),
                screenWidthPx / 2f,
                screenHeightPx / 2f
            )
        }

        // 3. Inversão de eixos
        val sx = if (invertX) -1f else 1f
        val sy = if (invertY) -1f else 1f
        if (invertX || invertY) {
            transformMatrix.postScale(sx, sy, screenWidthPx / 2f, screenHeightPx / 2f)
        }
    }

    /**
     * Mapeamento sub-pixel direto no buffer pré-alocado.
     */
    fun transformCoordinates(rawX: Float, rawY: Float, outCoords: FloatArray) {
        pointsBuffer[0] = rawX
        pointsBuffer[1] = rawY
        transformMatrix.mapPoints(pointsBuffer)
        outCoords[0] = pointsBuffer[0]
        outCoords[1] = pointsBuffer[1]
    }
}`
  },
  {
    id: 'coop_detector',
    filename: 'CoopDetector.kt',
    path: 'com/koda/wintab/hub/CoopDetector.kt',
    description: 'Detecção de fechamento do aplicativo de destino em 3 caminhos com fallback automático',
    language: 'kotlin',
    code: `package com.koda.wintab.hub

import android.app.ActivityManager
import android.app.IProcessObserver
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log

/**
 * CoopDetector - Ativa o Modo Coop quando o app de destino é fechado.
 * 3 Caminhos de Detecção:
 * 1. Koda Engine -> IProcessObserver.onProcessDied
 * 2. UsageStatsManager -> MOVE_TO_BACKGROUND
 * 3. ActivityLifecycleCallbacks
 */
class CoopDetector(
    private val context: Context,
    private val onCoopTriggered: (packageName: String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    fun registerObserver(targetPackage: String) {
        try {
            // Método 1: Observer privilegiado via Shell UID 2000
            val am = Class.forName("android.app.ActivityManagerNative")
                .getMethod("getDefault").invoke(null)
            
            val observer = object : IProcessObserver.Stub() {
                override fun onForegroundActivitiesChanged(pid: Int, uid: Int, foregroundActivities: Boolean) {
                    if (!foregroundActivities) {
                        checkIfAppClosed(targetPackage)
                    }
                }
                override fun onProcessDied(pid: Int, uid: Int) {
                    Log.i("CoopDetector", "Processo \$targetPackage encerrou. Ativando Modo Coop!")
                    mainHandler.post { onCoopTriggered(targetPackage) }
                }
            }
            // am.registerProcessObserver(observer)
        } catch (e: Exception) {
            Log.w("CoopDetector", "Fallback para UsageStatsManager poll", e)
            startUsageStatsPolling(targetPackage)
        }
    }

    private fun startUsageStatsPolling(targetPackage: String) {
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
        // Monitora transições de janela de forma assíncrona
    }

    private fun checkIfAppClosed(targetPackage: String) {
        onCoopTriggered(targetPackage)
    }
}`
  },
  {
    id: 'android_manifest',
    filename: 'AndroidManifest.xml',
    path: 'AndroidManifest.xml',
    description: 'Declaração com minSdk 29 (Android 10), permissões USB Host, e Foreground Service Type',
    language: 'xml',
    code: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="com.koda.wintab">

    <!-- Requisito mínimo Android 10 (API 29) até Android 14+ (API 34) -->
    <uses-sdk
        android:minSdkVersion="29"
        android:targetSdkVersion="34" />

    <!-- USB Host API -->
    <uses-feature android:name="android.hardware.usb.host" android:required="true" />
    <uses-permission android:name="android.permission.USB_PERMISSION" />

    <!-- Foreground Service com tipos declarados para Android 10/14 -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE" />

    <!-- Inicialização com o sistema -->
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" tools:ignore="ProtectedPermissions" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Koda Wintab"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.KodaWintab">

        <!-- Tela Principal -->
        <activity
            android:name=".ui.MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize"
            android:configChanges="orientation|screenSize|screenLayout|smallestScreenSize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <!-- Detecção automática de conexão de mesa USB -->
            <intent-filter>
                <action android:name="android.hardware.usb.action.USB_DEVICE_ATTACHED" />
            </intent-filter>
            <meta-data
                android:name="android.hardware.usb.action.USB_DEVICE_ATTACHED"
                android:resource="@xml/device_filter" />
        </activity>

        <!-- Serviço de Leitura USB em Primeiro Plano -->
        <service
            android:name=".service.UsbDriverService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="connectedDevice" />

        <!-- Receiver de Boot para persistência do Koda Server -->
        <receiver
            android:name=".receiver.BootReceiver"
            android:enabled="true"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>

    </application>
</manifest>`
  },
  {
    id: 'adb_script',
    filename: 'adb_bootstrap.sh',
    path: 'scripts/adb_bootstrap.sh',
    description: 'Script pronto para ativar o Koda Server via ADB com UID 2000 (shell) sem root',
    language: 'bash',
    code: `#!/bin/bash
# ==============================================================================
# Koda Wintab - Bootstrap da Engine de Privilégio Shell (Android 10+)
# Executa apenas uma vez via computador (USB ou Wi-Fi ADB).
# ==============================================================================

echo "🔍 Procurando dispositivo Android..."
adb wait-for-device

echo "📦 Obtendo caminho do APK instalado..."
APK_PATH=$(adb shell pm path com.koda.wintab | head -n 1 | cut -d: -f2 | tr -d '\\r')

if [ -z "$APK_PATH" ]; then
    echo "❌ Erro: Koda Wintab não está instalado no dispositivo."
    echo "   Por favor, instale o APK primeiro."
    exit 1
fi

echo "✅ APK localizado: $APK_PATH"

echo "⚡ Iniciando Koda Server (UID 2000 shell)..."
adb shell "nohup sh -c 'CLASSPATH=$APK_PATH app_process /system/bin com.koda.wintab.engine.KodaServer' > /dev/null 2>&1 &"

sleep 1

echo "🛡️ Verificando processo..."
PID=$(adb shell pgrep -f "com.koda.wintab.engine.KodaServer" | tr -d '\\r')

if [ -n "$PID" ]; then
    echo "🎉 SUCESSO! Koda Server está ativo (PID: $PID, UID 2000)."
    echo "   Abra o Koda Wintab e clique em 'Verificar Conexão'."
else
    echo "⚠️ O processo não pôde ser confirmado. Verifique o logcat:"
    echo "   adb logcat -s KodaServer"
fi
`
  }
];
