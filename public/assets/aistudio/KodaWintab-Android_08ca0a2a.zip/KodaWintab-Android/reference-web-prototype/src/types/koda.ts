export type ActiveView = 
  | 'home' 
  | 'activation' 
  | 'tablet' 
  | 'hub' 
  | 'coop' 
  | 'architecture' 
  | 'vm_testing';

export type TabletBrand = 'ugee' | 'wacom' | 'huion' | 'xppen' | 'generic';

export interface TabletDevice {
  id: string;
  name: string;
  brand: TabletBrand;
  vid: string; // e.g. "0x28BD"
  pid: string; // e.g. "0x0914"
  reportDescriptorLength: number;
  maxPressure: number; // 2048, 4096, 8192
  physicalWidthMm: number;
  physicalHeightMm: number;
  maxRawX: number;
  maxRawY: number;
  hasTilt: boolean;
  expressKeysCount: number;
  hasTouchRing: boolean;
  initControlTransferRequired: boolean;
}

export type OtdTab = 'tablet' | 'pen' | 'bindings' | 'filters' | 'output';

export interface TabletConfig {
  // Area & Alignment
  areaWidthMm: number;
  areaHeightMm: number;
  offsetX: number;
  offsetY: number;
  lockAspectRatio: boolean;
  rotation: 0 | 90 | 180 | 270;
  autoRotateWithScreen: boolean;
  invertX: boolean;
  invertY: boolean;

  // Pen & Pressure
  pressureCurve: 'linear' | 'soft' | 'firm' | 'aggressive' | 'scurve' | 'custom';
  customCurvePoints: [number, number][]; // [[0,0], [x1, y1], [x2, y2], [1, 1]]
  minPressureThreshold: number; // 0..1000
  maxPressureThreshold: number; // 7000..8192
  pressureSmoothing: boolean;

  // Bindings
  penTipAction: string;
  penButton1Action: string;
  penButton2Action: string;
  expressKeys: Record<string, string>; // K1..K8 -> shortcut string

  // Filters
  antiJitterEnabled: boolean;
  antiJitterRadius: number;
  bezierSmoothing: boolean;
  tiltCompensation: boolean;
  hysteresisThreshold: number;

  // Output
  outputMode: 'absolute' | 'relative';
  targetDisplay: 'internal' | 'dex' | 'pc_mode' | 'external';
  targetApp: string;
}

export interface HubDevice {
  id: string;
  slot: 'mouse1' | 'mouse2' | 'keyboard1' | 'keyboard2' | 'mesa1' | 'mesa2';
  name: string;
  hardwareName: string;
  type: 'mouse' | 'keyboard' | 'tablet';
  deviceId: number; // unique Android virtual device ID (e.g. 101, 102, 201, 202, 301, 302)
  targetApp: string;
  isCoop: boolean;
  cursorIcon?: string;
  cursorHotspot?: [number, number];
}

export interface TargetApplication {
  id: string;
  packageName: string;
  name: string;
  category: 'art' | 'system' | 'productivity';
  isRunning: boolean;
  windowMode: 'fullscreen' | 'freeform' | 'split';
}

export interface KodaEngineStatus {
  isActive: boolean;
  uid: number; // 2000 (shell)
  pid: number;
  sessionToken: string;
  uptimeSeconds: number;
  injectEventsPermission: boolean;
  windowManagerAccess: boolean;
  vbusControlActive: boolean;
  claimInterfaceForced: boolean;
  displayManagerAccess: boolean;
  processObserverRegistered: boolean;
  rebootPersistence: boolean;
}

export interface RawHidPacket {
  timestamp: number;
  hex: string;
  reportId: number;
  status: string; // "Tip Down", "Hover", "Button 1", "Eraser"
  x: number;
  y: number;
  pressure: number;
  tiltX?: number;
  tiltY?: number;
}
